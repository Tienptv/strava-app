import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { StravaAPI } from './strava.js';
import { scrapeClubActivities, loginAndGetCookie, getSavedCookie } from './scraper.js';
import https from 'https';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TARGETS_FILE = path.join(__dirname, '../Storage/targets.json');
const CONFIG_FILE = path.join(__dirname, '../Storage/challenge_config.json');
const IMPORTED_FILE = path.join(__dirname, '../Storage/imported_activities.json');
const HISTORICAL_FILE = path.join(__dirname, '../Storage/historical_activities.json');
const TOTAL_KM_FILE = path.join(__dirname, '../Storage/Tong km To 17082026.csv');
const GOAL_FILE = path.join(__dirname, '../Storage/club_goal.json');
const TOKENS_FILE = path.join(__dirname, '../Storage/tokens.json');
const NAME_MAPPING_FILE = path.join(__dirname, '../Storage/name_mapping.json');
const ADMINS_FILE = path.join(__dirname, '../Storage/admins.json');
const AUDIT_LOGS_FILE = path.join(__dirname, '../Storage/audit_logs.json');
const SUPER_ADMIN_ID = (process.env.VITE_ADMIN_STRAVA_ID || '133066813').toString();

function loadAdminsList() {
  try {
    if (fs.existsSync(ADMINS_FILE)) {
      const data = JSON.parse(fs.readFileSync(ADMINS_FILE, 'utf8'));
      return Array.isArray(data.adminIds) ? data.adminIds : [];
    }
  } catch (err) {
    console.error('Lỗi nạp admins:', err.message);
  }
  return [];
}

function saveAdminsList(adminIds) {
  try {
    const dir = path.dirname(ADMINS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(ADMINS_FILE, JSON.stringify({ adminIds }, null, 2), 'utf8');
  } catch (err) {
    console.error('Lỗi lưu admins:', err.message);
  }
}

function loadAuditLogs() {
  try {
    if (fs.existsSync(AUDIT_LOGS_FILE)) {
      const data = JSON.parse(fs.readFileSync(AUDIT_LOGS_FILE, 'utf8'));
      return Array.isArray(data) ? data : [];
    }
  } catch (err) {
    console.error('Lỗi nạp audit logs:', err.message);
  }
  return [];
}

function addAuditLog(action, user = 'System', details = '') {
  try {
    const logs = loadAuditLogs();
    const newEntry = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      action,
      user,
      details
    };
    logs.unshift(newEntry);
    const trimmed = logs.slice(0, 200);
    const dir = path.dirname(AUDIT_LOGS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(AUDIT_LOGS_FILE, JSON.stringify(trimmed, null, 2), 'utf8');
  } catch (err) {
    console.error('Lỗi ghi audit log:', err.message);
  }
}

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));

// Quản lý token xác thực Strava (lưu trữ cố định trong Storage/tokens.json)
const tokenStore = new Map();

function loadTokens() {
  try {
    if (fs.existsSync(TOKENS_FILE)) {
      const data = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8'));
      Object.keys(data).forEach(id => tokenStore.set(id, data[id]));
    }
  } catch (err) {
    console.error('Lỗi nạp tokens:', err.message);
  }
}

function saveTokens() {
  try {
    const dir = path.dirname(TOKENS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const obj = {};
    for (const [k, v] of tokenStore.entries()) {
      obj[k] = v;
    }
    fs.writeFileSync(TOKENS_FILE, JSON.stringify(obj, null, 2), 'utf8');
  } catch (err) {
    console.error('Lỗi lưu tokens:', err.message);
  }
}

// Nạp token khi khởi động server
loadTokens();

const strava = new StravaAPI(
  process.env.STRAVA_CLIENT_ID,
  process.env.STRAVA_CLIENT_SECRET
);

// ==========================================
// CSV PARSING & STORAGE AUTO-SYNC HELPERS
// ==========================================
const normalize = (n) => (n || '').trim().toLowerCase().replace(/[\.\s]/g, '');

function parseCSVLine(text) {
  let row = [''], inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    let c = text[i];
    if (c === '"') {
      if (inQuotes && text[i+1] === '"') { row[row.length-1] += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (c === ',' && !inQuotes) {
      row.push('');
    } else {
      row[row.length-1] += c;
    }
  }
  return row.map(s => s.trim().replace(/^["']|["']$/g, ''));
}

function parseStorageCSV(content) {
  const lines = content.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length === 0) return [];
  const rawHeaders = parseCSVLine(lines[0]);
  const headers = rawHeaders.map(h => h.replace(/["']/g, '').trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const vals = parseCSVLine(lines[i]);
    const obj = {};
    headers.forEach((h, idx) => { obj[h] = vals[idx] || ''; });
    rows.push(obj);
  }
  
  const activities = [];
  rows.forEach(row => {
    // Bỏ qua các hoạt động ẩn
    const isPrivate = String(row.private || row.Private || 'false').toLowerCase() === 'true';
    const hideFromHome = String(row.hide_from_home || row.Hide_from_home || 'false').toLowerCase() === 'true';
    const visibility = row.visibility || row.Visibility;
    if (isPrivate || hideFromHome || (visibility && String(visibility).toLowerCase() !== 'everyone')) {
      return;
    }

    let dist = parseFloat(String(row.Distance || 0).replace(',', '.').replace(/[^\d.-]/g, ''));
    dist = isNaN(dist) ? 0 : dist * 1000;
    
    let movingTimeStr = row['Duration'] || row['Moving Time'] || row['Time'] || '00:00:00';
    let timeParts = movingTimeStr.split(':').map(Number);
    let movingTimeSec = 0;
    if (timeParts.length === 3) movingTimeSec = timeParts[0] * 3600 + timeParts[1] * 60 + timeParts[2];
    else if (timeParts.length === 2) movingTimeSec = timeParts[0] * 60 + timeParts[1];

    let athleteId = null;
    let athleteName = row.Name || row.Athlete || '';
    if (row.Athlete && String(row.Athlete).includes('/athletes/')) {
      athleteId = parseInt(String(row.Athlete).replace('/athletes/', ''), 10);
      athleteName = row.Name || '';
    }

    let activityId = null;
    if (row.Activity) {
      const match = String(row.Activity).match(/\d+/);
      if (match) activityId = match[0];
    } else if (row['Activity ID'] || row.id || row.Id) {
      activityId = String(row['Activity ID'] || row.id || row.Id);
    }

    let nameParts = athleteName.trim().split(' ');
    let lastname = nameParts.length > 1 ? nameParts.pop() : '';
    let firstname = nameParts.join(' ');

    let dateStr = row.Date || '';
    let localIsoStr = null;
    if (dateStr.includes('T')) {
      localIsoStr = dateStr.substring(0, 19) + 'Z';
    } else if (dateStr) {
      if (dateStr.includes('/')) {
        let dParts = dateStr.split(' ')[0].split('/');
        let tPart = dateStr.split(' ')[1] || '00:00:00';
        if (dParts.length === 3) {
          if (dParts[0].length === 4) {
            dateStr = `${dParts[0]}-${String(dParts[1]).padStart(2, '0')}-${String(dParts[2]).padStart(2, '0')}T${tPart}Z`;
          } else {
            dateStr = `${dParts[2]}-${String(dParts[1]).padStart(2, '0')}-${String(dParts[0]).padStart(2, '0')}T${tPart}Z`;
          }
          localIsoStr = dateStr;
        }
      } else if (dateStr.includes('-')) {
        let parts = dateStr.split(' ');
        let dPart = parts[0];
        let tPart = parts[1] || '00:00:00';
        localIsoStr = `${dPart}T${tPart}Z`;
      }
    }

    if (dist > 0 && localIsoStr) {
      activities.push({
        id: activityId,
        type: row.Type || row['Activity Type'] || 'Run',
        distance: dist,
        moving_time: movingTimeSec,
        start_date_local: localIsoStr,
        athlete: {
          id: athleteId,
          firstname: firstname,
          lastname: lastname
        }
      });
    }
  });
  return activities;
}

function getCompKey(act) {
  const d = (act.start_date_local || '').substring(0, 16);
  const t = act.moving_time || 0;
  const dist = Math.round(act.distance || 0);
  const athId = act.athlete?.id || '';
  const name = `${normalize(act.athlete?.firstname)}_${normalize(act.athlete?.lastname)}`;
  return `comp_${athId || name}_${d}_${t}_${dist}`;
}

function isBetterRecord(a, b) {
  if (!b) return true;
  if (a.start_date_local && !b.start_date_local) return true;
  if (!a.start_date_local && b.start_date_local) return false;
  
  if (a.start_date_local && b.start_date_local) {
    const dateA = new Date(a.start_date_local);
    const dateB = new Date(b.start_date_local);
    // Prefer the later date for the same activity (the one with +7 hours timezone fix)
    if (dateA.getTime() > dateB.getTime()) return true;
    // Don't return false here yet, let it check lastname below if dates are exactly equal
  }
  
  // Giữ lại bản có tên họ đầy đủ hơn
  const aLastname = a.athlete?.lastname || '';
  const bLastname = b.athlete?.lastname || '';
  if (aLastname.length > 2 && bLastname.length <= 2) return true;
  
  return false;
}

function mergeActivitiesList(existingList, newList) {
  const uniqueMap = new Map();

  const addRecord = (act) => {
    if (!act) return;
    const idKey = act.id ? `id_${act.id}` : null;
    const cKey = getCompKey(act);

    if (idKey) {
      const existing = uniqueMap.get(idKey);
      if (!existing || isBetterRecord(act, existing)) {
        uniqueMap.set(idKey, act);
      }
    }
    
    const existingComp = uniqueMap.get(cKey);
    if (!existingComp || isBetterRecord(act, existingComp)) {
      uniqueMap.set(cKey, act);
    }
  };

  (existingList || []).forEach(addRecord);
  (newList || []).forEach(addRecord);

  const finalSet = new Set(uniqueMap.values());
  return Array.from(finalSet).filter(a => !a.start_date_local || a.start_date_local >= '2026-08-01T00:00:00');
}

function syncAllStorageCsv() {
  try {
    const storageDir = path.join(__dirname, '../Storage');
    if (!fs.existsSync(storageDir)) return [];

    let existingActivities = [];
    if (fs.existsSync(IMPORTED_FILE)) {
      try {
        existingActivities = JSON.parse(fs.readFileSync(IMPORTED_FILE, 'utf8'));
        if (!Array.isArray(existingActivities)) existingActivities = [];
      } catch (e) {
        existingActivities = [];
      }
    }

    let csvFiles = fs.readdirSync(storageDir).filter(f => f.startsWith('data-') && f.endsWith('.csv'));
    csvFiles.sort(); // Sắp xếp theo tên (tên chứa thời gian nên sẽ tăng dần)
    
    let isUpdated = false;

    for (const f of csvFiles) {
      try {
        const content = fs.readFileSync(path.join(storageDir, f), 'utf8');
        let fileActivities = parseStorageCSV(content);
        
        if (fileActivities.length > 0) {
          fileActivities = mapAthleteNamesUsingCSV(fileActivities);
          
          existingActivities = mergeActivitiesList(existingActivities, fileActivities);
          isUpdated = true;
        }
      } catch (err) {
        console.error(`Lỗi đọc file CSV ${f}:`, err.message);
      }
    }

    if (isUpdated) {
      fs.writeFileSync(IMPORTED_FILE, JSON.stringify(existingActivities, null, 2), 'utf8');
    }
    return existingActivities;
  } catch (err) {
    console.error('Lỗi syncAllStorageCsv:', err.message);
    return [];
  }
}

// Không tự động đồng bộ CSV khi khởi động server nữa
// syncAllStorageCsv();

// ==========================================
// AUTH ROUTES
// ==========================================

// Lấy URL đăng nhập Strava
app.get('/api/auth/url', (req, res) => {
  const redirectUri = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/callback`;
  const scope = 'read,read_all,activity:read,activity:read_all';
  const authUrl = `https://www.strava.com/oauth/authorize?client_id=${process.env.STRAVA_CLIENT_ID}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&approval_prompt=auto`;
  res.json({ url: authUrl });
});

// Đổi authorization code lấy access token
app.post('/api/auth/token', async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) {
      return res.status(400).json({ error: 'Thiếu authorization code' });
    }

    const redirectUri = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/callback`;
    const tokenData = await strava.exchangeToken(code, redirectUri);

    // Lưu token với athlete ID làm key
    const athleteId = tokenData.athlete.id;
    tokenStore.set(athleteId.toString(), {
      access_token: tokenData.access_token,
      refresh_token: tokenData.refresh_token,
      expires_at: tokenData.expires_at,
    });
    saveTokens();

    // Tự động ghi nhận thành viên vào AthleteID_Name.csv và name_mapping.json
    try {
      const ath = tokenData.athlete;
      if (ath && ath.id) {
        const fn = (ath.firstname || '').trim();
        const ln = (ath.lastname || '').trim();
        const fullName = `${fn} ${ln}`.trim();
        if (fullName && !ln.endsWith('.')) {
          registerAthleteToCsvAndMapping({
            athleteId: ath.id,
            fullName: fullName,
            avatarUrl: ath.profile_medium || ath.profile || ''
          });
        }
      }
    } catch (regErr) {
      console.warn('Lỗi tự động đăng ký athlete khi login:', regErr.message);
    }

    res.json({
      athlete: tokenData.athlete,
      athleteId: athleteId,
      expires_at: tokenData.expires_at,
    });
  } catch (error) {
    console.error('Lỗi đổi token:', error.message);
    res.status(500).json({ error: 'Không thể xác thực với Strava' });
  }
});

// ==========================================
// ADMIN & ROLES ROUTES
// ==========================================

// Kiểm tra vai trò của người dùng hiện tại
app.get('/api/auth/roles', (req, res) => {
  const athleteId = (req.headers['x-athlete-id'] || '').toString();
  const subAdmins = loadAdminsList();
  
  const isSuperAdmin = !!athleteId && athleteId === SUPER_ADMIN_ID;
  const isSubAdmin = !!athleteId && subAdmins.includes(athleteId);
  const isAdmin = isSuperAdmin || isSubAdmin;
  
  res.json({
    athleteId,
    superAdminId: SUPER_ADMIN_ID,
    isSuperAdmin,
    isSubAdmin,
    isAdmin
  });
});

// Lấy danh sách Sub-Admins
app.get('/api/admins', (req, res) => {
  const subAdmins = loadAdminsList();
  res.json(subAdmins);
});

// Cấp quyền Sub-Admin mới (chỉ Super Admin)
app.post('/api/admins', (req, res) => {
  const currentAthleteId = (req.headers['x-athlete-id'] || '').toString();
  if (currentAthleteId !== SUPER_ADMIN_ID) {
    return res.status(403).json({ error: 'Chỉ Super Admin mới có quyền cấp quyền Admin' });
  }

  const { adminId, name } = req.body;
  if (!adminId) {
    return res.status(400).json({ error: 'Thiếu ID thành viên' });
  }

  const subAdmins = loadAdminsList();
  const idStr = adminId.toString();
  if (!subAdmins.includes(idStr)) {
    subAdmins.push(idStr);
    saveAdminsList(subAdmins);
    addAuditLog('Cấp quyền Admin', `Super Admin (${currentAthleteId})`, `Cấp quyền admin cho ID: ${idStr} ${name ? `(${name})` : ''}`);
  }

  res.json({ success: true, admins: subAdmins });
});

// Thu hồi quyền Sub-Admin (chỉ Super Admin)
app.delete('/api/admins/:id', (req, res) => {
  const currentAthleteId = (req.headers['x-athlete-id'] || '').toString();
  if (currentAthleteId !== SUPER_ADMIN_ID) {
    return res.status(403).json({ error: 'Chỉ Super Admin mới có quyền thu hồi quyền Admin' });
  }

  const targetId = req.params.id.toString();
  let subAdmins = loadAdminsList();
  subAdmins = subAdmins.filter(id => id.toString() !== targetId);
  saveAdminsList(subAdmins);
  addAuditLog('Thu hồi quyền Admin', `Super Admin (${currentAthleteId})`, `Thu hồi quyền admin của ID: ${targetId}`);

  res.json({ success: true, admins: subAdmins });
});

// Lấy nhật ký hoạt động (Audit Logs)
app.get('/api/admin/audit-logs', (req, res) => {
  const logs = loadAuditLogs();
  res.json(logs);
});

// Xóa nhật ký hoạt động
app.delete('/api/admin/audit-logs', (req, res) => {
  const currentAthleteId = (req.headers['x-athlete-id'] || '').toString();
  const subAdmins = loadAdminsList();
  if (currentAthleteId !== SUPER_ADMIN_ID && !subAdmins.includes(currentAthleteId)) {
    return res.status(403).json({ error: 'Không có quyền thực hiện thao tác này' });
  }
  
  try {
    fs.writeFileSync(AUDIT_LOGS_FILE, JSON.stringify([], null, 2), 'utf8');
  } catch (e) {}
  addAuditLog('Dọn dẹp nhật ký', currentAthleteId || 'Admin', 'Đã xóa toàn bộ bản ghi audit log cũ');
  res.json({ success: true, logs: [] });
});

// Lấy thống kê các tệp dữ liệu trong Storage
app.get('/api/admin/storage-stats', (req, res) => {
  const fileKeys = [
    { key: 'imported_activities.json', name: 'Hoạt động đã nhập (Imported Activities)', file: IMPORTED_FILE, desc: 'Chứa toàn bộ hoạt động của câu lạc bộ đã đồng bộ' },
    { key: 'targets.json', name: 'Mục tiêu & Phạt (Targets & Penalties)', file: TARGETS_FILE, desc: 'Mục tiêu km và trạng thái phạt theo tháng của VĐV' },
    { key: 'challenge_config.json', name: 'Cấu hình thử thách (Challenge Config)', file: CONFIG_FILE, desc: 'Danh sách người tham gia và cấu hình tháng' },
    { key: 'club_goal.json', name: 'Mục tiêu nhóm & Điểm đến (Club Goal)', file: GOAL_FILE, desc: 'Quãng đường mục tiêu toàn nhóm và hành trình bản đồ' },
    { key: 'name_mapping.json', name: 'Bảng quy đổi tên (Name Mapping)', file: NAME_MAPPING_FILE, desc: 'Từ điển mapping tên rút gọn Strava sang tên đầy đủ' },
    { key: 'admins.json', name: 'Danh sách Admin (Admins List)', file: ADMINS_FILE, desc: 'Danh sách ID các Sub-Admin được phân quyền' },
    { key: 'audit_logs.json', name: 'Nhật ký hoạt động (Audit Logs)', file: AUDIT_LOGS_FILE, desc: 'Lịch sử thao tác hệ thống và đồng bộ' },
    { key: 'tokens.json', name: 'Phiên đăng nhập Strava (Tokens)', file: TOKENS_FILE, desc: 'Token OAuth Strava của các người dùng' }
  ];

  const stats = fileKeys.map(f => {
    let exists = false;
    let size = 0;
    let count = 0;
    let lastModified = null;

    if (fs.existsSync(f.file)) {
      exists = true;
      const stat = fs.statSync(f.file);
      size = stat.size;
      lastModified = stat.mtime;
      try {
        const content = JSON.parse(fs.readFileSync(f.file, 'utf8'));
        if (Array.isArray(content)) count = content.length;
        else if (typeof content === 'object' && content !== null) {
          if (content.adminIds) count = content.adminIds.length;
          else if (content.participants) count = Object.keys(content.participants).length;
          else count = Object.keys(content).length;
        }
      } catch (e) {}
    }

    return {
      key: f.key,
      name: f.name,
      desc: f.desc,
      exists,
      size,
      count,
      lastModified
    };
  });

  res.json({ success: true, files: stats });
});

// Tạo backup ngay tức thì
app.post('/api/admin/backup', (req, res) => {
  const currentAthleteId = (req.headers['x-athlete-id'] || '').toString();
  try {
    const { execSync } = require('child_process');
    const now = new Date();
    const timestamp = now.getFullYear().toString() + 
      (now.getMonth() + 1).toString().padStart(2, '0') + 
      now.getDate().toString().padStart(2, '0') + '_' + 
      now.getHours().toString().padStart(2, '0') + 
      now.getMinutes().toString().padStart(2, '0') + 
      now.getSeconds().toString().padStart(2, '0');
    
    const backupFileName = `strava-app-backup-${timestamp}.zip`;
    const backupFilePath = path.join(__dirname, '..', backupFileName);
    
    execSync(`powershell -Command "Get-ChildItem -Path . -Exclude node_modules, .git, .env | Compress-Archive -DestinationPath '${backupFilePath}' -Force"`, { cwd: path.join(__dirname, '..') });
    
    addAuditLog('Tạo bản sao lưu', currentAthleteId || 'Admin', `Đã tạo file backup: ${backupFileName}`);
    res.json({ success: true, filename: backupFileName });
  } catch (err) {
    console.error('Lỗi tạo backup:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// MIDDLEWARE: Lấy token từ header
// ==========================================
async function getToken(req, res, next) {
  const athleteId = req.headers['x-athlete-id'];
  if (!athleteId) {
    return res.status(401).json({ error: 'Thiếu athlete ID' });
  }
  let tokenData = tokenStore.get(athleteId);
  if (!tokenData) {
    loadTokens();
    tokenData = tokenStore.get(athleteId);
  }
  if (!tokenData) {
    return res.status(401).json({ error: 'Chưa đăng nhập' });
  }

  // Tự động refresh token nếu token hết hạn hoặc sắp hết hạn trong 5 phút
  const nowSec = Math.floor(Date.now() / 1000);
  if (tokenData.expires_at && tokenData.expires_at - nowSec < 300 && tokenData.refresh_token) {
    try {
      console.log(`🔄 Tự động refresh token cho athlete ${athleteId}...`);
      const refreshed = await strava.refreshToken(tokenData.refresh_token);
      tokenData = {
        access_token: refreshed.access_token,
        refresh_token: refreshed.refresh_token || tokenData.refresh_token,
        expires_at: refreshed.expires_at,
      };
      tokenStore.set(athleteId, tokenData);
      saveTokens();
    } catch (err) {
      console.error('Lỗi refresh token:', err.message);
    }
  }

  req.accessToken = tokenData.access_token;
  req.athleteId = athleteId;
  next();
}

// ==========================================
// ATHLETE ROUTES
// ==========================================

// Lấy thông tin athlete hiện tại
app.get('/api/athlete', getToken, async (req, res) => {
  try {
    const athlete = await strava.getAthlete(req.accessToken);
    res.json(athlete);
  } catch (error) {
    console.error('Lỗi lấy athlete:', error.message);
    res.status(500).json({ error: 'Không thể lấy thông tin athlete' });
  }
});

// Lấy thống kê của athlete
app.get('/api/athlete/stats', getToken, async (req, res) => {
  try {
    const stats = await strava.getAthleteStats(req.accessToken, req.athleteId);
    res.json(stats);
  } catch (error) {
    console.error('Lỗi lấy stats:', error.message);
    res.status(500).json({ error: 'Không thể lấy thống kê' });
  }
});

// ==========================================
// ACTIVITY ROUTES
// ==========================================

// Lấy danh sách activities
app.get('/api/activities', getToken, async (req, res) => {
  try {
    const { page = 1, per_page = 30, after, before } = req.query;
    const activities = await strava.getActivities(req.accessToken, {
      page: parseInt(page),
      per_page: parseInt(per_page),
      after: after ? parseInt(after) : undefined,
      before: before ? parseInt(before) : undefined,
    });
    res.json(activities);
  } catch (error) {
    console.error('Lỗi lấy activities:', error.message);
    res.status(500).json({ error: 'Không thể lấy danh sách hoạt động' });
  }
});

// Lấy chi tiết một activity
app.get('/api/activities/:id', getToken, async (req, res) => {
  try {
    const activity = await strava.getActivity(req.accessToken, req.params.id);
    res.json(activity);
  } catch (error) {
    console.error('Lỗi lấy activity:', error.message);
    res.status(500).json({ error: 'Không thể lấy chi tiết hoạt động' });
  }
});

// ==========================================
// CLUB ROUTES
// ==========================================

// Lấy danh sách clubs mà athlete tham gia
app.get('/api/clubs', getToken, async (req, res) => {
  try {
    const clubs = await strava.getAthleteClubs(req.accessToken);
    res.json(clubs);
  } catch (error) {
    console.error('Lỗi lấy clubs:', error.message);
    res.status(500).json({ error: 'Không thể lấy danh sách câu lạc bộ' });
  }
});

// Lấy thông tin chi tiết club
app.get('/api/clubs/:id', getToken, async (req, res) => {
  try {
    const club = await strava.getClub(req.accessToken, req.params.id);
    res.json(club);
  } catch (error) {
    console.error('Lỗi lấy club:', error.message);
    res.status(500).json({ error: 'Không thể lấy thông tin câu lạc bộ' });
  }
});

// ==========================================
// AUTO-SYNC ATHLETE HELPERS (CSV & MAPPING)
// ==========================================

// Hàm tra cứu Public Profile của Strava (không cần token OAuth, lấy Full Name và Avatar gốc)
function fetchStravaPublicProfile(athleteId) {
  return new Promise((resolve) => {
    if (!athleteId) return resolve(null);
    const cleanId = athleteId.toString().trim();
    if (!/^\d+$/.test(cleanId)) return resolve(null);

    const url = `https://www.strava.com/athletes/${cleanId}`;
    const req = https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      },
      timeout: 10000
    }, (res) => {
      let html = '';
      res.on('data', chunk => { html += chunk; });
      res.on('end', () => {
        let fullName = null;
        let avatarUrl = null;

        const ogTitleMatch = html.match(/<meta property="og:title" content="([^"]+)"/i);
        if (ogTitleMatch) {
          fullName = ogTitleMatch[1].replace(/\s*\|\s*Strava Athlete Profile.*$/i, '').trim();
        } else {
          const twitterTitleMatch = html.match(/<meta name="twitter:title" content="([^"]+)"/i);
          if (twitterTitleMatch) {
            fullName = twitterTitleMatch[1].replace(/\s*\|\s*Strava Athlete Profile.*$/i, '').trim();
          }
        }

        const ogImageMatch = html.match(/<meta property="og:image" content="([^"]+)"/i);
        if (ogImageMatch) {
          avatarUrl = ogImageMatch[1].trim();
        }

        if (fullName && fullName !== 'Strava' && !fullName.includes('Log In') && !fullName.endsWith('.')) {
          resolve({ athleteId: cleanId, fullName, avatarUrl });
        } else {
          resolve(null);
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });

    req.on('error', () => {
      resolve(null);
    });
  });
}

// Hàm dùng chung: Tự động ghi nhận Athlete vào AthleteID_Name.csv, name_mapping.json và challenge_config.json
function registerAthleteToCsvAndMapping({ athleteId, fullName, avatarUrl }) {
  if (!athleteId || !fullName) return false;
  const cleanId = athleteId.toString().trim();
  const cleanName = fullName.trim();
  if (!cleanId || !cleanName || cleanName === 'Name' || cleanName.endsWith('.')) return false;

  let csvUpdated = false;
  const athleteNamesFile = path.join(__dirname, '../Storage/AthleteID_Name.csv');
  try {
    let existingCsv = '';
    if (fs.existsSync(athleteNamesFile)) {
      existingCsv = fs.readFileSync(athleteNamesFile, 'utf8');
    }
    const existingIds = new Set(
      existingCsv.split(/\r?\n/).map(l => l.split(',')[0].trim()).filter(Boolean)
    );

    if (!existingIds.has(cleanId)) {
      const newLine = existingCsv.endsWith('\n') ? `${cleanId},${cleanName}\n` : `\n${cleanId},${cleanName}\n`;
      fs.appendFileSync(athleteNamesFile, newLine, 'utf8');
      csvUpdated = true;
      console.log(`📝 [Auto-Sync] Added to AthleteID_Name.csv: ${cleanId} -> ${cleanName}`);
    }
  } catch (err) {
    console.warn('Lỗi ghi AthleteID_Name.csv:', err.message);
  }

  const nameParts = cleanName.split(' ');
  const fn = nameParts[0];
  const ln = nameParts.slice(1).join(' ');
  const initial = ln ? ln.charAt(0).toUpperCase() + '.' : '';
  const matchKey = `${fn}_${initial}`;
  const abbrevName = `${fn} ${initial}`.trim();

  // Cập nhật name_mapping.json
  try {
    let nameMappingJson = {};
    if (fs.existsSync(NAME_MAPPING_FILE)) {
      nameMappingJson = JSON.parse(fs.readFileSync(NAME_MAPPING_FILE, 'utf8'));
    }

    let mappingChanged = false;
    if (!nameMappingJson[cleanName] || nameMappingJson[cleanName].fullName !== cleanName) {
      nameMappingJson[cleanName] = { key: matchKey, fullName: cleanName, athleteId: cleanId };
      mappingChanged = true;
    }
    if (matchKey && (!nameMappingJson[matchKey] || nameMappingJson[matchKey].fullName !== cleanName)) {
      nameMappingJson[matchKey] = { abbreviatedName: abbrevName, fullName: cleanName, athleteId: cleanId };
      mappingChanged = true;
    }
    if (abbrevName && (!nameMappingJson[abbrevName] || nameMappingJson[abbrevName].fullName !== cleanName)) {
      nameMappingJson[abbrevName] = { key: matchKey, fullName: cleanName, athleteId: cleanId };
      mappingChanged = true;
    }

    if (mappingChanged) {
      fs.writeFileSync(NAME_MAPPING_FILE, JSON.stringify(nameMappingJson, null, 2), 'utf8');
    }
  } catch (mErr) {
    console.warn('Lỗi cập nhật name_mapping.json:', mErr.message);
  }

  // Cập nhật challenge_config.json nếu participant đang có tên viết tắt hoặc thiếu avatar
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      let configChanged = false;

      const updateParticipantObj = (p) => {
        if (!p) return;
        if ((!p.lastname || p.lastname.endsWith('.') || !p.name || p.name.endsWith('.')) && ln) {
          p.firstname = fn;
          p.lastname = ln;
          p.name = cleanName;
          configChanged = true;
        }
        if (!p.athleteId) {
          p.athleteId = cleanId;
          p.id = cleanId;
          configChanged = true;
        }
        const isBadAvatar = !p.profile_medium || p.profile_medium.includes('avatar/athlete') || p.profile_medium.includes('logo-strava');
        if (avatarUrl && isBadAvatar) {
          p.profile_medium = avatarUrl;
          p.profile = avatarUrl;
          configChanged = true;
        }
      };

      if (config.participants) {
        if (config.participants[matchKey]) {
          updateParticipantObj(config.participants[matchKey]);
        }
        Object.values(config.participants).forEach(p => {
          if (p.athleteId === cleanId || p.id === cleanId) {
            updateParticipantObj(p);
          }
        });
      }

      if (config.monthlyParticipants) {
        Object.values(config.monthlyParticipants).forEach(monthMap => {
          if (monthMap[matchKey]) {
            updateParticipantObj(monthMap[matchKey]);
          }
          Object.values(monthMap).forEach(p => {
            if (p.athleteId === cleanId || p.id === cleanId) {
              updateParticipantObj(p);
            }
          });
        });
      }

      if (configChanged) {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
      }
    }
  } catch (cErr) {
    console.warn('Lỗi cập nhật challenge_config.json:', cErr.message);
  }

  return csvUpdated;
}

// Hàm hỗ trợ lấy Full Name từ Storage/AthleteID_Name.csv
function getFullNameMapping() {
  const athleteNamesFile = path.join(__dirname, '../Storage/AthleteID_Name.csv');
  const mapping = {};
  if (fs.existsSync(athleteNamesFile)) {
    const lines = fs.readFileSync(athleteNamesFile, 'utf8').split('\n');
    lines.forEach(line => {
      const parts = line.trim().split(',');
      if (parts.length >= 2) {
        const id = parts[0].trim();
        const fullName = parts.slice(1).join(',').trim();
        if (fullName && fullName !== 'Name') {
          const nameParts = fullName.split(' ');
          const fn = nameParts[0];
          const ln = nameParts.slice(1).join(' ');
          
          if (ln) {
            const initial = ln.charAt(0).toUpperCase() + '.';
            const matchKey = `${fn}_${initial}`.toLowerCase();
            mapping[matchKey] = { firstname: fn, lastname: ln };
          } else {
            mapping[fn.toLowerCase()] = { firstname: fn, lastname: '' };
          }
        }
      }
    });
  }
  return mapping;
}

// Lấy thành viên của club
app.get('/api/clubs/:id/members', getToken, async (req, res) => {
  try {
    const { page = 1, per_page = 30 } = req.query;
    const mapping = getFullNameMapping();

    // Helper: convert config participants object -> member array
    const configToMemberArray = (participants) => {
      return Object.entries(participants || {}).map(([matchKey, data]) => ({
        id: data.athleteId || null,
        matchKey: matchKey,
        firstname: data.firstname || matchKey.split('_')[0] || '',
        lastname: data.lastname || '',
        membership: data.membership || 'member',
        admin: data.admin || false,
        owner: data.owner || false,
        profile_medium: data.profile_medium || data.profile || '',
        profile: data.profile || data.profile_medium || '',
        resource_state: data.resource_state || 2,
        name: data.name || `${data.firstname || ''} ${data.lastname || ''}`.trim(),
        _fromConfig: true
      }));
    };

    let members = [];
    let fromStrava = false;

    try {
      members = await strava.getClubMembers(req.accessToken, req.params.id, {
        page: parseInt(page),
        per_page: parseInt(per_page),
      });
      fromStrava = true;
    } catch (stravaErr) {
      console.warn('Strava API lỗi, dùng fallback từ config:', stravaErr.message);
    }

    // Load config to get saved profile data and fallback members
    let configParticipants = {};
    if (fs.existsSync(CONFIG_FILE)) {
      try {
        const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        configParticipants = cfg.participants || {};
      } catch (e) { /* ignore */ }
    }

    if (!fromStrava || !Array.isArray(members) || members.length === 0) {
      // Fallback: return all participants from config as member list
      members = configToMemberArray(configParticipants);
    } else {
      // Merge profile/avatar from config into Strava results (Strava API v3 often omits profile for club members)
      members = members.map(member => {
        const fn = member.firstname || '';
        const ln = member.lastname || '';
        const initial = ln ? ln.charAt(0).toUpperCase() + '.' : '';
        const matchKey = `${fn}_${initial}`;
        const cfgData = configParticipants[matchKey];

        // Apply full name from mapping
        const mappingKey = matchKey.toLowerCase();
        const fullNameEntry = mapping[mappingKey];
        if (fullNameEntry) {
          member = {
            ...member,
            matchKey,
            firstname: fullNameEntry.firstname || member.firstname,
            lastname: fullNameEntry.lastname || member.lastname,
          };
        } else {
          member.matchKey = matchKey;
        }

        // Merge avatar from config if Strava didn't provide one
        if (cfgData && (!member.profile_medium || member.profile_medium.includes('avatar/athlete') || member.profile_medium.includes('logo-strava'))) {
          return {
            ...member,
            profile_medium: cfgData.profile_medium || member.profile_medium || '',
            profile: cfgData.profile || member.profile || '',
          };
        }
        return member;
      });
    }

    res.json(members);
  } catch (error) {
    console.error('Lỗi lấy members:', error.message);
    // Last resort fallback
    try {
      if (fs.existsSync(CONFIG_FILE)) {
        const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        const members = Object.entries(cfg.participants || {}).map(([key, data]) => ({
          id: data.athleteId || null,
          firstname: data.firstname || '',
          lastname: data.lastname || '',
          profile_medium: data.profile_medium || '',
          profile: data.profile || '',
          membership: data.membership || 'member',
          admin: data.admin || false,
          owner: data.owner || false,
        }));
        return res.json(members);
      }
    } catch (e2) { /* ignore */ }
    res.status(500).json({ error: 'Không thể lấy danh sách thành viên' });
  }
});

// Đồng bộ thông tin thành viên (Cập nhật Tên và Avatar)
app.post('/api/admin/sync-members', getToken, async (req, res) => {
  try {
    const configPath = CONFIG_FILE;
    if (!fs.existsSync(configPath)) {
      return res.status(404).json({ error: 'Config not found' });
    }
    
    let configStr = fs.readFileSync(configPath, 'utf8');
    let config = JSON.parse(configStr);
    
    if (!config.clubId) {
      return res.status(400).json({ error: 'Chưa cấu hình Club ID' });
    }

    let members = [];
    let page = 1;
    let hasMore = true;
    
    while (hasMore) {
      const pageMembers = await strava.getClubMembers(req.accessToken, config.clubId, {
        page: page,
        per_page: 200,
      });
      
      if (Array.isArray(pageMembers) && pageMembers.length > 0) {
        members = members.concat(pageMembers);
        if (pageMembers.length < 200) {
          hasMore = false;
        } else {
          page++;
        }
      } else {
        hasMore = false;
      }
    }

    if (members.length === 0) {
      return res.status(500).json({ error: 'Không lấy được danh sách thành viên Strava' });
    }

    const mapping = getFullNameMapping(); // keys are lowercase e.g. "abba_v."
    
    // Load existing name_mapping.json to update athlete IDs for the scraper
    let nameMappingJson = {};
    try {
      if (fs.existsSync(NAME_MAPPING_FILE)) {
        nameMappingJson = JSON.parse(fs.readFileSync(NAME_MAPPING_FILE, 'utf8'));
      }
    } catch (e) { console.error('Error loading name_mapping.json:', e); }

    let mappingUpdated = false;
    const stravaMembersMap = {}; // keyed by matchKey e.g. "Abba_V."
    
    members.forEach(m => {
      let firstname = m.firstname || '';
      let lastname = m.lastname || '';
      
      const initial = lastname ? lastname.charAt(0).toUpperCase() + '.' : '';
      const matchKey = `${firstname}_${initial}`;
      const matchKeyLower = matchKey.toLowerCase();
      
      // FIX: Strava club members API returns athlete id as m.id (not m.athlete.id)
      const athleteId = m.id ? m.id.toString() : null;
      
      // Update name_mapping.json for the fetch_avatars script
      if (athleteId) {
        if (!nameMappingJson[matchKey]) {
          nameMappingJson[matchKey] = {
            abbreviatedName: `${firstname} ${initial}`,
            fullName: `${firstname} ${lastname}`,
            athleteId: athleteId
          };
          mappingUpdated = true;
        } else if (nameMappingJson[matchKey].athleteId !== athleteId) {
          nameMappingJson[matchKey].athleteId = athleteId;
          mappingUpdated = true;
        }
      }
      
      // FIX: getFullNameMapping() returns lowercase keys - use matchKeyLower to lookup
      const fullNameEntry = mapping[matchKeyLower];
      if (fullNameEntry) {
        firstname = fullNameEntry.firstname || firstname;
        lastname = fullNameEntry.lastname || lastname;
      }
      
      stravaMembersMap[matchKey] = {
        resource_state: m.resource_state || 2,
        name: `${firstname} ${lastname}`.trim(),
        firstname: firstname,
        lastname: lastname,
        membership: m.membership || 'member',
        admin: m.admin || false,
        owner: m.owner || false,
        profile_medium: m.profile_medium || m.profile || '',
        profile: m.profile || m.profile_medium || '',
        athleteId: athleteId
      };
    });

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 2: Fetch club activities để lấy athlete ID + profile đầy đủ
    // Club activities API trả về athlete.id và profile_medium cho mỗi người
    // ─────────────────────────────────────────────────────────────────────────
    console.log('Đang fetch club activities để lấy athlete IDs...');
    const activitiesAthleteMap = {}; // matchKey -> { id, profile_medium, profile, firstname, lastname }
    const athleteIdToMatchKey = {}; // athleteId -> matchKey (để reverse lookup)

    try {
      let actPage = 1;
      const MAX_ACTIVITY_PAGES = 10; // Fetch tối đa 10 trang (2000 activities)
      let keepFetching = true;

      while (keepFetching && actPage <= MAX_ACTIVITY_PAGES) {
        const activities = await strava.getClubActivities(req.accessToken, config.clubId, {
          page: actPage,
          per_page: 200,
        });

        if (!Array.isArray(activities) || activities.length === 0) break;

        activities.forEach(act => {
          const ath = act.athlete;
          if (!ath || !ath.id) return;

          const fn = ath.firstname || '';
          const ln = ath.lastname || '';
          const initial = ln ? ln.charAt(0).toUpperCase() + '.' : '';
          const matchKey = `${fn}_${initial}`;
          const athId = ath.id.toString();

          // Lưu mapping athleteId <-> matchKey
          athleteIdToMatchKey[athId] = matchKey;

          // Chỉ lưu nếu chưa có hoặc profile mới có URL đầy đủ hơn
          const existing = activitiesAthleteMap[matchKey];
          const hasGoodProfile = ath.profile_medium && 
            !ath.profile_medium.includes('avatar/athlete') && 
            !ath.profile_medium.includes('logo-strava');

          if (!existing || (hasGoodProfile && !existing.hasGoodProfile)) {
            activitiesAthleteMap[matchKey] = {
              athleteId: athId,
              profile_medium: ath.profile_medium || '',
              profile: ath.profile || ath.profile_medium || '',
              firstname: fn,
              lastname: ln,
              hasGoodProfile: hasGoodProfile
            };
          }
        });

        if (activities.length < 200) keepFetching = false;
        else actPage++;
      }

      console.log(`Đã quét ${actPage} trang activities, tìm thấy ${Object.keys(activitiesAthleteMap).length} athletes.`);

      // Merge dữ liệu từ activities vào stravaMembersMap
      Object.entries(activitiesAthleteMap).forEach(([matchKey, actData]) => {
        if (stravaMembersMap[matchKey]) {
          // Cập nhật athleteId nếu chưa có
          if (!stravaMembersMap[matchKey].athleteId) {
            stravaMembersMap[matchKey].athleteId = actData.athleteId;
          }
          // Cập nhật profile nếu activity có URL tốt hơn
          if (actData.hasGoodProfile && !stravaMembersMap[matchKey].profile_medium) {
            stravaMembersMap[matchKey].profile_medium = actData.profile_medium;
            stravaMembersMap[matchKey].profile = actData.profile;
          }
        } else {
          // Member xuất hiện trong activities nhưng chưa có trong members list
          // (ví dụ: đã rời group nhưng có activity cũ, bỏ qua)
        }

        // Cập nhật name_mapping.json với athleteId từ activities
        const athId = actData.athleteId;
        if (athId) {
          if (!nameMappingJson[matchKey]) {
            nameMappingJson[matchKey] = {
              abbreviatedName: `${actData.firstname} ${actData.firstname ? actData.lastname.charAt(0) + '.' : ''}`.trim(),
              fullName: `${actData.firstname} ${actData.lastname}`.trim(),
              athleteId: athId
            };
            mappingUpdated = true;
          } else if (!nameMappingJson[matchKey].athleteId) {
            nameMappingJson[matchKey].athleteId = athId;
            mappingUpdated = true;
          }
        }
      });

      // Cập nhật athleteId vào stravaMembersMap cho các member còn thiếu
      Object.entries(stravaMembersMap).forEach(([matchKey, data]) => {
        if (!data.athleteId && activitiesAthleteMap[matchKey]) {
          stravaMembersMap[matchKey].athleteId = activitiesAthleteMap[matchKey].athleteId;
          mappingUpdated = true;
        }
      });

    } catch (actErr) {
      console.warn('Không thể fetch club activities (vẫn tiếp tục):', actErr.message);
    }

    if (mappingUpdated) {
      fs.writeFileSync(NAME_MAPPING_FILE, JSON.stringify(nameMappingJson, null, 2), 'utf8');
    }

    // Cập nhật AthleteID_Name.csv với member mới (tự động tra cứu public profile nếu tên bị viết tắt)
    const athleteIdCsvPath = path.join(__dirname, '../Storage/AthleteID_Name.csv');
    try {
      let existingCsv = '';
      if (fs.existsSync(athleteIdCsvPath)) {
        existingCsv = fs.readFileSync(athleteIdCsvPath, 'utf8');
      }
      const existingIds = new Set(
        existingCsv.split(/\r?\n/).map(l => l.split(',')[0].trim()).filter(Boolean)
      );

      for (const data of Object.values(stravaMembersMap)) {
        // Nếu thiếu athleteId nhưng avatar có chứa ID dạng /athletes/{id}/, tự trích xuất
        if (!data.athleteId && data.profile_medium && data.profile_medium.includes('/athletes/')) {
          const idMatch = data.profile_medium.match(/\/athletes\/(\d+)\//);
          if (idMatch) {
            data.athleteId = idMatch[1];
          }
        }

        const athId = data.athleteId;
        const isAbbrev = !data.lastname || data.lastname.endsWith('.') || !data.name || data.name.endsWith('.');
        const isMissingFromCsv = athId && !existingIds.has(athId);

        if (athId && (isAbbrev || isMissingFromCsv)) {
          try {
            const profile = await fetchStravaPublicProfile(athId);
            if (profile && profile.fullName) {
              const nameParts = profile.fullName.trim().split(' ');
              const fn = nameParts[0];
              const ln = nameParts.slice(1).join(' ');
              data.firstname = fn;
              data.lastname = ln;
              data.name = profile.fullName;
              if (profile.avatarUrl && (!data.profile_medium || data.profile_medium.includes('avatar/athlete') || data.profile_medium.includes('logo-strava'))) {
                data.profile_medium = profile.avatarUrl;
                data.profile = profile.avatarUrl;
              }
              registerAthleteToCsvAndMapping({
                athleteId: athId,
                fullName: profile.fullName,
                avatarUrl: profile.avatarUrl
              });
              existingIds.add(athId);
            } else if (!isAbbrev && isMissingFromCsv) {
              const fullName = data.name || `${data.firstname} ${data.lastname}`.trim();
              registerAthleteToCsvAndMapping({
                athleteId: athId,
                fullName: fullName,
                avatarUrl: data.profile_medium || ''
              });
              existingIds.add(athId);
            }
          } catch (pErr) {
            console.warn(`Lỗi tra cứu public profile cho athlete ${athId}:`, pErr.message);
          }
        } else if (athId && !isAbbrev && isMissingFromCsv) {
          const fullName = data.name || `${data.firstname} ${data.lastname}`.trim();
          registerAthleteToCsvAndMapping({
            athleteId: athId,
            fullName: fullName,
            avatarUrl: data.profile_medium || ''
          });
          existingIds.add(athId);
        }
      }
    } catch (csvErr) {
      console.warn('Không thể cập nhật AthleteID_Name.csv:', csvErr.message);
    }

    // Determine current month key for auto-adding new members
    const now = new Date();
    const currentMonthKey = `${now.getFullYear()}_${now.getMonth() + 1}`;

    let updatedCount = 0;
    let newMemberCount = 0;
    const trackedIds = new Set();

    // Update existing participants AND add new members
    if (!config.participants) config.participants = {};
    
    Object.entries(stravaMembersMap).forEach(([matchKey, memberData]) => {
      if (config.participants[matchKey]) {
        // Update existing participant
        config.participants[matchKey].name = memberData.name;
        config.participants[matchKey].firstname = memberData.firstname;
        config.participants[matchKey].lastname = memberData.lastname;
        config.participants[matchKey].profile_medium = memberData.profile_medium;
        config.participants[matchKey].profile = memberData.profile;
        config.participants[matchKey].admin = memberData.admin;
        config.participants[matchKey].owner = memberData.owner;
        if (memberData.athleteId) config.participants[matchKey].athleteId = memberData.athleteId;
        trackedIds.add(matchKey);
      } else {
        // NEW MEMBER: Add to participants
        config.participants[matchKey] = {
          resource_state: memberData.resource_state,
          firstname: memberData.firstname,
          lastname: memberData.lastname,
          membership: memberData.membership,
          admin: memberData.admin,
          owner: memberData.owner,
          profile_medium: memberData.profile_medium,
          profile: memberData.profile,
          name: memberData.name,
          avatar: '',
          athleteId: memberData.athleteId || ''
        };
        trackedIds.add(matchKey);
        newMemberCount++;
        console.log(`✨ New member added: ${matchKey} (${memberData.name})`);
      }
    });

    // Update monthlyParticipants for all existing months
    if (config.monthlyParticipants) {
      Object.keys(config.monthlyParticipants).forEach(month => {
        Object.keys(config.monthlyParticipants[month]).forEach(id => {
          if (stravaMembersMap[id]) {
            config.monthlyParticipants[month][id].name = stravaMembersMap[id].name;
            config.monthlyParticipants[month][id].firstname = stravaMembersMap[id].firstname;
            config.monthlyParticipants[month][id].lastname = stravaMembersMap[id].lastname;
            config.monthlyParticipants[month][id].profile_medium = stravaMembersMap[id].profile_medium;
            config.monthlyParticipants[month][id].profile = stravaMembersMap[id].profile;
            trackedIds.add(id);
          }
        });
      });
    }

    // Auto-add new members to current month's monthlyParticipants
    if (newMemberCount > 0) {
      if (!config.monthlyParticipants) config.monthlyParticipants = {};
      if (!config.monthlyParticipants[currentMonthKey]) {
        config.monthlyParticipants[currentMonthKey] = {};
      }
      Object.entries(stravaMembersMap).forEach(([matchKey, memberData]) => {
        if (!config.monthlyParticipants[currentMonthKey][matchKey]) {
          config.monthlyParticipants[currentMonthKey][matchKey] = {
            resource_state: memberData.resource_state,
            firstname: memberData.firstname,
            lastname: memberData.lastname,
            membership: memberData.membership,
            admin: memberData.admin,
            owner: memberData.owner,
            profile_medium: memberData.profile_medium,
            profile: memberData.profile,
            name: memberData.name,
            avatar: ''
          };
        }
      });
    }
    
    updatedCount = trackedIds.size;

    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
    
    // Tích hợp chạy 2 lệnh lấy avatar nâng cao
    try {
      const { exec } = await import('child_process');
      const util = await import('util');
      const execPromise = util.promisify(exec);
      
      console.log('Đang chạy fetch_avatars.cjs...');
      await execPromise('node server/fetch_avatars.cjs', { env: process.env, cwd: path.join(__dirname, '..') });
      
      console.log('Đang chạy update_config_avatars.cjs...');
      await execPromise('node server/update_config_avatars.cjs', { env: process.env, cwd: path.join(__dirname, '..') });
      console.log('Đã cập nhật avatar nâng cao thành công!');
    } catch (scriptErr) {
      console.error('Lỗi khi chạy script cập nhật avatar:', scriptErr.message);
      // Không ném lỗi ra ngoài để luồng chính vẫn thành công
    }
    
    const currentAthleteId = (req.headers['x-athlete-id'] || '').toString();
    addAuditLog('Đồng bộ Thành viên', currentAthleteId || 'Admin', 
      `Đã cập nhật Tên/Avatar cho ${updatedCount} thành viên (${newMemberCount} thành viên mới)`);

    res.json({ success: true, updatedCount, newMemberCount });
  } catch (err) {
    console.error('Lỗi đồng bộ thành viên:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Lấy activities gần đây của club
app.get('/api/clubs/:id/activities', getToken, async (req, res) => {
  try {
    const { page = 1, per_page = 30 } = req.query;
    const activities = await strava.getClubActivities(req.accessToken, req.params.id, {
      page: parseInt(page),
      per_page: parseInt(per_page),
    });
    res.json(activities);
  } catch (error) {
    console.error('Lỗi lấy club activities:', error.message);
    res.status(500).json({ error: 'Không thể lấy hoạt động câu lạc bộ' });
  }
});

// ==========================================
// TARGET & PENALTY ROUTES
// ==========================================

// Đọc dữ liệu target/penalty
app.get('/api/challenge/targets', (req, res) => {
  try {
    if (fs.existsSync(TARGETS_FILE)) {
      const data = fs.readFileSync(TARGETS_FILE, 'utf8');
      res.json(JSON.parse(data));
    } else {
      res.json({});
    }
  } catch (error) {
    console.error('Lỗi đọc targets:', error.message);
    res.status(500).json({ error: 'Không thể đọc dữ liệu' });
  }
});

// Cập nhật dữ liệu target/penalty
app.post('/api/challenge/targets', (req, res) => {
  try {
    const payload = req.body;
    let data = {};
    if (fs.existsSync(TARGETS_FILE)) {
      try {
        data = JSON.parse(fs.readFileSync(TARGETS_FILE, 'utf8'));
      } catch (e) {
        data = {};
      }
    }
    
    if (Array.isArray(payload)) {
      payload.forEach(item => {
        if (item && item.matchKey) {
          if (!data[item.matchKey]) data[item.matchKey] = {};
          if (item.target !== undefined) data[item.matchKey].target = item.target;
          if (item.penalty !== undefined) data[item.matchKey].penalty = item.penalty;
        }
      });
    } else if (payload && payload.matchKey) {
      const { matchKey, target, penalty } = payload;
      if (!data[matchKey]) {
        data[matchKey] = {};
      }
      if (target !== undefined) data[matchKey].target = target;
      if (penalty !== undefined) data[matchKey].penalty = penalty;
    } else if (payload && typeof payload === 'object') {
      // Direct object map { [matchKey]: { target, penalty } }
      Object.keys(payload).forEach(key => {
        if (payload[key] && typeof payload[key] === 'object') {
          if (!data[key]) data[key] = {};
          if (payload[key].target !== undefined) data[key].target = payload[key].target;
          if (payload[key].penalty !== undefined) data[key].penalty = payload[key].penalty;
        }
      });
    } else {
      return res.status(400).json({ error: 'Dữ liệu không hợp lệ' });
    }

    // Đảm bảo thư mục tồn tại
    const dir = path.dirname(TARGETS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(TARGETS_FILE, JSON.stringify(data, null, 2));
    res.json(data);
  } catch (error) {
    console.error('Lỗi lưu targets:', error.message);
    res.status(500).json({ error: 'Không thể lưu dữ liệu targets' });
  }
});

// ==========================================
// CONFIG & IMPORTED ROUTES
// ==========================================

// Lấy file mapping tên
app.get('/api/challenge/name-mapping', (req, res) => {
  try {
    if (fs.existsSync(NAME_MAPPING_FILE)) {
      const data = fs.readFileSync(NAME_MAPPING_FILE, 'utf8');
      res.json(JSON.parse(data));
    } else {
      res.json({});
    }
  } catch (error) {
    console.error('Error reading name mapping:', error);
    res.json({});
  }
});

// Đọc cấu hình (participants, clubId)
app.get('/api/challenge/config', (req, res) => {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf8');
      const config = JSON.parse(data);
      
      // Gắn Full Name tự động cho config để UI luôn hiển thị đúng
      const mapping = getFullNameMapping();
      
      if (config.participants) {
        Object.keys(config.participants).forEach(key => {
          const mappingEntry = mapping[key.toLowerCase()];
          if (mappingEntry) {
            config.participants[key].firstname = mappingEntry.firstname;
            config.participants[key].lastname = mappingEntry.lastname;
            config.participants[key].name = `${mappingEntry.firstname} ${mappingEntry.lastname}`.trim();
          }
        });
      }
      
      if (config.monthlyParticipants) {
        Object.keys(config.monthlyParticipants).forEach(month => {
          const monthData = config.monthlyParticipants[month];
          Object.keys(monthData).forEach(key => {
            const mappingEntry = mapping[key.toLowerCase()];
            if (mappingEntry) {
              monthData[key].firstname = mappingEntry.firstname;
              monthData[key].lastname = mappingEntry.lastname;
              monthData[key].name = `${mappingEntry.firstname} ${mappingEntry.lastname}`.trim();
            }
          });
        });
      }
      
      res.json(config);
    } else {
      res.json({ participants: {}, clubId: '' });
    }
  } catch (error) {
    console.error('Lỗi đọc config:', error.message);
    res.status(500).json({ error: 'Không thể đọc cấu hình' });
  }
});

// Lưu cấu hình
app.post('/api/challenge/config', (req, res) => {
  try {
    let existingConfig = { participants: {}, monthlyParticipants: {}, clubId: '' };
    if (fs.existsSync(CONFIG_FILE)) {
      try {
        existingConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      } catch (e) {}
    }

    const payload = req.body;
    const merged = {
      ...existingConfig,
      ...payload,
      monthlyParticipants: {
        ...(existingConfig.monthlyParticipants || {}),
        ...(payload.monthlyParticipants || {})
      }
    };

    if (payload.monthKey && payload.participants) {
      merged.monthlyParticipants[payload.monthKey] = payload.participants;
    }

    const dir = path.dirname(CONFIG_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(merged, null, 2));
    res.json(merged);
  } catch (error) {
    console.error('Lỗi lưu config:', error.message);
    res.status(500).json({ error: 'Không thể lưu cấu hình' });
  }
});

// Đọc mục tiêu câu lạc bộ (Club Goal)
app.get('/api/challenge/goal', (req, res) => {
  try {
    if (fs.existsSync(GOAL_FILE)) {
      const data = fs.readFileSync(GOAL_FILE, 'utf8');
      res.json(JSON.parse(data));
    } else {
      res.json({ targetKm: 9000, customTitle: null, customSubtitle: null });
    }
  } catch (error) {
    console.error('Lỗi đọc goal:', error.message);
    res.status(500).json({ error: 'Không thể đọc mục tiêu câu lạc bộ' });
  }
});

// Lưu mục tiêu câu lạc bộ (Club Goal)
app.post('/api/challenge/goal', (req, res) => {
  try {
    const data = req.body;
    const dir = path.dirname(GOAL_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(GOAL_FILE, JSON.stringify(data, null, 2));
    res.json(data);
  } catch (error) {
    console.error('Lỗi lưu goal:', error.message);
    res.status(500).json({ error: 'Không thể lưu mục tiêu câu lạc bộ' });
  }
});

// Đọc historical activities (Tháng 7/2026 trở về trước)
app.get('/api/challenge/historical', (req, res) => {
  try {
    if (fs.existsSync(HISTORICAL_FILE)) {
      const data = fs.readFileSync(HISTORICAL_FILE, 'utf8');
      res.json(JSON.parse(data));
    } else {
      res.json([]);
    }
  } catch (error) {
    console.error('Lỗi đọc historical:', error.message);
    res.status(500).json({ error: 'Không thể đọc dữ liệu historical' });
  }
});

// Lưu historical activities
app.post('/api/challenge/historical', (req, res) => {
  try {
    const data = req.body;
    const dir = path.dirname(HISTORICAL_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(HISTORICAL_FILE, JSON.stringify(data, null, 2));
    res.json(data);
  } catch (error) {
    console.error('Lỗi lưu historical:', error.message);
    res.status(500).json({ error: 'Không thể lưu dữ liệu historical' });
  }
});

// Đọc imported activities (Tháng 8/2026 trở đi)
app.get('/api/challenge/imported', (req, res) => {
  try {
    if (fs.existsSync(IMPORTED_FILE)) {
      const data = fs.readFileSync(IMPORTED_FILE, 'utf8');
      res.json(JSON.parse(data));
    } else {
      res.json([]);
    }
  } catch (error) {
    console.error('Lỗi đọc imported:', error.message);
    res.status(500).json({ error: 'Không thể đọc dữ liệu imported' });
  }
});

// Endpoint kích hoạt quét & đồng bộ toàn bộ file CSV trong Storage
app.post('/api/challenge/sync-storage', (req, res) => {
  try {
    const data = syncAllStorageCsv();
    res.json({ success: true, count: data.length, activities: data });
  } catch (error) {
    console.error('Lỗi sync-storage:', error.message);
    res.status(500).json({ error: 'Không thể đồng bộ file CSV trong Storage' });
  }
});

// Tự động lấy hoạt động của club từ Strava, tạo CSV và đồng bộ
app.post('/api/clubs/:id/auto-sync', getToken, async (req, res) => {
  try {
    const clubId = req.params.id;
    // 1. Get up to 50 activities from Strava
    const stravaActivities = await strava.getClubActivities(req.accessToken, clubId, { page: 1, per_page: 50 });
    
    // 2. Filter for 'Run', 'VirtualRun', 'TrailRun' activities
    const runActivities = stravaActivities.filter(act => {
      const t = (act.sport_type || act.type || '').toLowerCase();
      return ['run', 'virtualrun', 'trailrun', 'trail run'].includes(t) || t.includes('run') || t.includes('trail');
    });
    
    // 3. Format as CSV
    // Header: Name,Activity ID,Date,Title,Distance,Calories,Time,Activity Type
    let csvContent = "Name,Activity ID,Date,Title,Distance,Calories,Time,Activity Type\n";
    runActivities.forEach(act => {
      const name = act.athlete ? `${act.athlete.firstname || ''} ${act.athlete.lastname || ''}`.trim() : 'Unknown Athlete';
      const id = act.id || '';
      const date = act.start_date_local || act.start_date || '';
      const title = `"${(act.name || '').replace(/"/g, '""')}"`;
      const distance = ((act.distance || 0) / 1000).toFixed(2);
      const calories = 0;
      
      const totalSeconds = act.moving_time || 0;
      const h = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
      const m = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
      const s = (totalSeconds % 60).toString().padStart(2, '0');
      const time = `${h}:${m}:${s}`;
      
      let type = act.sport_type || act.type || 'Run';
      const lowerType = type.toLowerCase().replace(/[\s_-]/g, '');
      if (lowerType.includes('trail')) type = 'TrailRun';
      else if (lowerType.includes('virtual')) type = 'VirtualRun';
      else if (lowerType.includes('run')) type = 'Run';
      
      csvContent += `${name},${id},${date},${title},${distance},${calories},${time},${type}\n`;
    });
    
    // 4. Save to Storage
    const storageDir = path.join(__dirname, '../Storage');
    if (!fs.existsSync(storageDir)) {
      fs.mkdirSync(storageDir, { recursive: true });
    }
    
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}-${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}${String(now.getSeconds()).padStart(2,'0')}`;
    const filename = `data-autosync-${timestamp}.csv`;
    const filepath = path.join(storageDir, filename);
    
    fs.writeFileSync(filepath, csvContent, 'utf8');
    
    // 5. Update imported_activities.json directly with smart wipe logic
    let fileActivities = parseStorageCSV(csvContent);
    if (fileActivities.length > 0) {
      fileActivities = mapAthleteNamesUsingCSV(fileActivities);
      
      let existing = [];
      if (fs.existsSync(IMPORTED_FILE)) {
        try {
          existing = JSON.parse(fs.readFileSync(IMPORTED_FILE, 'utf8'));
          if (!Array.isArray(existing)) existing = [];
        } catch (e) { existing = []; }
      }
      
      let minDate = null;
      let maxDate = null;
      fileActivities.forEach(act => {
        if (act.start_date_local) {
          const dateStr = act.start_date_local.substring(0, 10);
          if (!minDate || dateStr < minDate) minDate = dateStr;
          if (!maxDate || dateStr > maxDate) maxDate = dateStr;
        }
      });
      
      if (minDate && maxDate) {
        existing = existing.filter(act => {
          if (!act.start_date_local) return true;
          const dateStr = act.start_date_local.substring(0, 10);
          return dateStr < minDate || dateStr > maxDate;
        });
      }
      
      const mergedData = mergeActivitiesList(existing, fileActivities);
      fs.writeFileSync(IMPORTED_FILE, JSON.stringify(mergedData, null, 2), 'utf8');
      
      res.json({ success: true, count: mergedData.length, activities: mergedData, synced_from_strava: runActivities.length, filename });
    } else {
      res.json({ success: true, count: 0, activities: [], synced_from_strava: 0, filename });
    }
  } catch (error) {
    console.error('Lỗi auto-sync club activities:', error.message);
    res.json({ success: false, error: error.message, stack: error.stack });
  }
});

// Mở Chrome để user đăng nhập Strava, tự động lấy cookie
app.post('/api/strava/login', async (req, res) => {
  try {
    const cookie = await loginAndGetCookie();
    res.json({ success: true, cookie });
  } catch (error) {
    console.error('Lỗi login Strava:', error.message);
    res.json({ success: false, error: error.message });
  }
});

// Lấy cookie đã lưu
app.get('/api/strava/cookie', (req, res) => {
  const cookie = getSavedCookie();
  res.json({ hasCookie: !!cookie, cookie: cookie || '' });
});

// Tự động cạo dữ liệu của club bằng Puppeteer
app.post('/api/clubs/:id/auto-sync-scrape', async (req, res) => {
  try {
    const clubId = req.params.id;
    let cookie = req.body.cookie;
    let limit = req.body.limit || 50;
    
    // Auto-use saved cookie if none provided
    if (!cookie) {
      cookie = getSavedCookie();
    }
    
    if (!cookie) {
      return res.status(400).json({ success: false, error: 'Thiếu Strava Session Cookie. Vui lòng đăng nhập trước.' });
    }

    // 1. Scrape activities using Puppeteer
    const scrapedActivities = await scrapeClubActivities(clubId, cookie, limit);
    
    // 2. Filter for 'Run', 'VirtualRun', 'TrailRun' activities and limit to the requested amount
    const runActivities = scrapedActivities.filter(act => {
      const t = (act.type || '').toLowerCase();
      return ['run', 'virtualrun', 'trailrun', 'trail run'].includes(t) || t.includes('run') || t.includes('trail');
    }).slice(0, limit);
    
    // 3. Format as CSV
    // Header: Name,Activity ID,Date,Title,Distance,Calories,Time,Activity Type
    let csvContent = "Name,Activity ID,Date,Title,Distance,Calories,Time,Activity Type\n";
    runActivities.forEach(act => {
      const name = `"${(act.athleteName || 'Unknown Athlete').replace(/"/g, '""')}"`;
      const id = act.id || '';
      const date = act.date || '';
      const title = `"${(act.title || '').replace(/"/g, '""')}"`;
      
      const distance = `"${act.distance}"`;
      const calories = 0;
      
      // Parse time like "1h 45m" or "45m 30s" to HH:mm:ss
      let rawTime = act.time.toLowerCase();
      let h = 0, m = 0, s = 0;
      const hMatch = rawTime.match(/(\d+)h/);
      const mMatch = rawTime.match(/(\d+)m/);
      const sMatch = rawTime.match(/(\d+)s/);
      if (hMatch) h = parseInt(hMatch[1]);
      if (mMatch) m = parseInt(mMatch[1]);
      if (sMatch) s = parseInt(sMatch[1]);
      const time = `"${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}"`;
      
      let type = act.type || 'Run';
      const lowerType = type.toLowerCase().replace(/[\s_-]/g, '');
      if (lowerType.includes('trail')) type = 'TrailRun';
      else if (lowerType.includes('virtual')) type = 'VirtualRun';
      else if (lowerType.includes('run')) type = 'Run';
      
      csvContent += `${name},${id},${date},${title},${distance},${calories},${time},${type}\n`;
    });
    
    // 4. Save to Storage
    const storageDir = path.join(__dirname, '../Storage');
    if (!fs.existsSync(storageDir)) {
      fs.mkdirSync(storageDir, { recursive: true });
    }
    
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}-${String(now.getHours()).padStart(2,'0')}${String(now.getMinutes()).padStart(2,'0')}${String(now.getSeconds()).padStart(2,'0')}`;
    const filename = `data-autosync-scrape-${timestamp}.csv`;
    const filepath = path.join(storageDir, filename);
    
    fs.writeFileSync(filepath, csvContent, 'utf8');
    
    // 5. Update imported_activities.json directly with smart wipe logic
    let fileActivities = parseStorageCSV(csvContent);
    if (fileActivities.length > 0) {
      fileActivities = mapAthleteNamesUsingCSV(fileActivities);
      
      let existing = [];
      if (fs.existsSync(IMPORTED_FILE)) {
        try {
          existing = JSON.parse(fs.readFileSync(IMPORTED_FILE, 'utf8'));
          if (!Array.isArray(existing)) existing = [];
        } catch (e) { existing = []; }
      }
      
      const dailyRanges = {};
      fileActivities.forEach(act => {
        if (act.start_date_local) {
          const dateStr = act.start_date_local.substring(0, 10);
          const actTime = new Date(act.start_date_local).getTime();
          if (!dailyRanges[dateStr]) {
            dailyRanges[dateStr] = { min: actTime, max: actTime };
          } else {
            if (actTime < dailyRanges[dateStr].min) dailyRanges[dateStr].min = actTime;
            if (actTime > dailyRanges[dateStr].max) dailyRanges[dateStr].max = actTime;
          }
        }
      });
      
      const intervals = Object.values(dailyRanges).map(range => ({
        min: range.min - 4000,
        max: range.max + 4000
      }));
      
      if (intervals.length > 0) {
        existing = existing.filter(act => {
          if (!act.start_date_local) return true;
          const actTime = new Date(act.start_date_local).getTime();
          const isWithinAnyInterval = intervals.some(interval => actTime >= interval.min && actTime <= interval.max);
          return !isWithinAnyInterval;
        });
      }
      
      const mergedData = mergeActivitiesList(existing, fileActivities);
      fs.writeFileSync(IMPORTED_FILE, JSON.stringify(mergedData, null, 2), 'utf8');
      
      res.json({ success: true, count: mergedData.length, activities: mergedData, scraped_count: runActivities.length, filename });
    } else {
      res.json({ success: true, count: 0, activities: [], scraped_count: 0, filename });
    }
  } catch (error) {
    console.error('Lỗi auto-sync-scrape:', error.message);
    res.json({ success: false, error: error.message, stack: error.stack });
  }
});


// Hàm hỗ trợ map tên dựa trên AthleteID_Name.csv
function mapAthleteNamesUsingCSV(activities) {
  const mappingFile = path.join(__dirname, '../Storage/AthleteID_Name.csv');
  const mappingById = {};
  const mappingByName = {};
  
  if (fs.existsSync(mappingFile)) {
      const lines = fs.readFileSync(mappingFile, 'utf8').split('\n');
      lines.forEach(line => {
          const parts = line.trim().split(',');
          if (parts.length >= 2) {
              const id = parts[0].trim();
              const fullName = parts.slice(1).join(',').trim();
              
              if (fullName && fullName !== 'Name') {
                  const nameParts = fullName.split(' ');
                  const fn = nameParts[0];
                  const ln = nameParts.slice(1).join(' ');
                  const mappedName = { firstname: fn, lastname: ln };
                  
                  if (id && id !== 'Athlete ID') {
                      mappingById[id] = mappedName;
                  }
                  
                  if (ln) {
                      const initial = ln.charAt(0).toUpperCase() + '.';
                      const matchKey = `${fn}_${initial}`.toLowerCase();
                      mappingByName[matchKey] = mappedName;
                  }
              }
          }
      });
  }

  return activities.map(act => {
      if (act.athlete) {
          let newName = null;
          // 1. Try mapping by ID
          if (act.athlete.id && mappingById[act.athlete.id]) {
              newName = mappingById[act.athlete.id];
          } 
          // 2. Try mapping by Match Key
          else if (act.athlete.firstname) {
              const fn = act.athlete.firstname;
              const ln = act.athlete.lastname || '';
              const initial = ln ? ln.charAt(0).toUpperCase() + '.' : '';
              const matchKey = `${fn}_${initial}`.toLowerCase();
              if (mappingByName[matchKey]) {
                  newName = mappingByName[matchKey];
              }
          }

          if (newName) {
              return {
                  ...act,
                  athlete: {
                      ...act.athlete,
                      firstname: newName.firstname,
                      lastname: newName.lastname
                  }
              };
          }
      }
      return act;
  });
}

// Lưu imported activities
app.post('/api/challenge/imported', (req, res) => {
  try {
    let data = req.body;
    if (Array.isArray(data)) {
        // Tự động phát hiện và đăng ký Athlete ID mới từ activities được tải lên
        try {
          data.forEach(act => {
            if (act.athlete && act.athlete.id) {
              const athId = act.athlete.id.toString();
              const fn = (act.athlete.firstname || '').trim();
              const ln = (act.athlete.lastname || '').trim();
              const fullName = `${fn} ${ln}`.trim();
              if (fullName && !ln.endsWith('.') && fullName !== 'Unknown Athlete') {
                registerAthleteToCsvAndMapping({
                  athleteId: athId,
                  fullName: fullName
                });
              }
            }
          });
        } catch (e) {
          console.warn('Lỗi auto-register từ imported activities:', e.message);
        }
        data = mapAthleteNamesUsingCSV(data);
    }

    let existing = [];
    if (fs.existsSync(IMPORTED_FILE)) {
      try {
        existing = JSON.parse(fs.readFileSync(IMPORTED_FILE, 'utf8'));
        if (!Array.isArray(existing)) existing = [];
      } catch (e) {
        existing = [];
      }
    }

    // Nếu có query replaceByDate, tìm khoảng thời gian (min, max) của file tải lên
    // và xóa tất cả các activity cũ nằm trong khoảng thời gian đó.
    if (req.query.replaceByDate === 'true' && Array.isArray(data) && data.length > 0) {
        const dailyRanges = {};

        data.forEach(act => {
            if (act.start_date_local) {
                const dateStr = act.start_date_local.substring(0, 10); // YYYY-MM-DD
                const actTime = new Date(act.start_date_local).getTime();
                if (!dailyRanges[dateStr]) {
                    dailyRanges[dateStr] = { min: actTime, max: actTime };
                } else {
                    if (actTime < dailyRanges[dateStr].min) dailyRanges[dateStr].min = actTime;
                    if (actTime > dailyRanges[dateStr].max) dailyRanges[dateStr].max = actTime;
                }
            }
        });

        const intervals = Object.values(dailyRanges).map(range => ({
            min: range.min - 4000, // nới rộng 4s
            max: range.max + 4000  // nới rộng 4s
        }));

        if (intervals.length > 0) {
            existing = existing.filter(act => {
                if (!act.start_date_local) return true;
                const actTime = new Date(act.start_date_local).getTime();
                // Check if actTime falls into ANY of the intervals
                const isWithinAnyInterval = intervals.some(interval => actTime >= interval.min && actTime <= interval.max);
                // Keep it if it does NOT fall into any interval
                return !isWithinAnyInterval;
            });
        }
    }

    const merged = Array.isArray(data) ? mergeActivitiesList(existing, data) : existing;

    const dir = path.dirname(IMPORTED_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(IMPORTED_FILE, JSON.stringify(merged, null, 2), 'utf8');
    res.json(merged);
  } catch (error) {
    console.error('Lỗi lưu imported:', error.message);
    res.status(500).json({ error: 'Không thể lưu dữ liệu imported' });
  }
});

// Endpoint bảo trì/tự động quét và sửa lỗi tên thành viên bị viết tắt
app.post('/api/admin/auto-fix-members', getToken, async (req, res) => {
  try {
    if (!fs.existsSync(CONFIG_FILE)) {
      return res.status(404).json({ error: 'Config not found' });
    }

    const config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    const athleteNamesFile = path.join(__dirname, '../Storage/AthleteID_Name.csv');
    let existingCsv = '';
    if (fs.existsSync(athleteNamesFile)) {
      existingCsv = fs.readFileSync(athleteNamesFile, 'utf8');
    }
    const idToName = {};
    const nameToId = {};
    existingCsv.split(/\r?\n/).forEach(l => {
      const p = l.split(',');
      if (p.length >= 2 && p[0].trim() && p[1].trim() && p[1].trim() !== 'Name') {
        const id = p[0].trim();
        const name = p.slice(1).join(',').trim();
        idToName[id] = name;
        nameToId[name.toLowerCase()] = id;
      }
    });

    let fixedCount = 0;
    const fixedDetails = [];

    // Duyệt qua participants trong config
    for (const [key, p] of Object.entries(config.participants || {})) {
      let athId = p.athleteId || p.id;
      
      // Nếu chưa có ID, thử trích xuất từ avatar URL
      if (!athId && p.profile_medium && p.profile_medium.includes('/athletes/')) {
        const m = p.profile_medium.match(/\/athletes\/(\d+)\//);
        if (m) athId = m[1];
      }

      // Nếu vẫn chưa có ID, thử tìm trong AthleteID_Name.csv theo tên
      if (!athId && p.name && nameToId[p.name.toLowerCase()]) {
        athId = nameToId[p.name.toLowerCase()];
      }

      const isAbbrev = !p.lastname || p.lastname.endsWith('.') || !p.name || p.name.endsWith('.');
      
      if (athId) {
        p.athleteId = athId;
        p.id = athId;

        // Nếu tên bị viết tắt, tra cứu public profile để lấy tên đầy đủ & avatar xịn
        if (isAbbrev) {
          try {
            const profile = await fetchStravaPublicProfile(athId);
            if (profile && profile.fullName) {
              const parts = profile.fullName.trim().split(' ');
              p.firstname = parts[0];
              p.lastname = parts.slice(1).join(' ');
              p.name = profile.fullName;
              if (profile.avatarUrl) {
                p.profile_medium = profile.avatarUrl;
                p.profile = profile.avatarUrl;
              }
              registerAthleteToCsvAndMapping({
                athleteId: athId,
                fullName: profile.fullName,
                avatarUrl: profile.avatarUrl
              });
              fixedCount++;
              fixedDetails.push({ key, id: athId, fixedName: profile.fullName });
            }
          } catch (err) {
            console.warn(`Lỗi fix athlete ${athId}:`, err.message);
          }
        } else {
          // Tên đã đầy đủ, đảm bảo đã đăng ký vào CSV
          registerAthleteToCsvAndMapping({
            athleteId: athId,
            fullName: p.name,
            avatarUrl: p.profile_medium || ''
          });
        }
      }
    }

    // Cập nhật lại monthlyParticipants nếu có
    if (config.monthlyParticipants) {
      Object.values(config.monthlyParticipants).forEach(monthMap => {
        Object.entries(monthMap).forEach(([key, p]) => {
          if (config.participants && config.participants[key]) {
            const master = config.participants[key];
            p.firstname = master.firstname;
            p.lastname = master.lastname;
            p.name = master.name;
            p.athleteId = master.athleteId;
            p.id = master.id;
            if (master.profile_medium) {
              p.profile_medium = master.profile_medium;
              p.profile = master.profile;
            }
          }
        });
      });
    }

    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    res.json({ success: true, fixedCount, fixedDetails });
  } catch (error) {
    console.error('Lỗi auto-fix-members:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// TOTAL-KM BASELINE ROUTES
// ==========================================

// Đọc dữ liệu All-Time km từ file CSV Tong km To 17082026.csv
app.get('/api/challenge/total-km', (req, res) => {
  try {
    let filePath = TOTAL_KM_FILE;
    if (!fs.existsSync(filePath)) {
      const storageDir = path.join(__dirname, '../Storage');
      if (fs.existsSync(storageDir)) {
        // Find 'Tong km*.csv' first
        let files = fs.readdirSync(storageDir).filter(f => f.startsWith('Tong km') && f.endsWith('.csv'));
        if (files.length === 0) {
          // Fallback to 'Total-km*.csv'
          files = fs.readdirSync(storageDir).filter(f => f.startsWith('Total-km') && f.endsWith('.csv'));
        }
        if (files.length > 0) {
          filePath = path.join(storageDir, files[0]);
        }
      }
    }

    if (!fs.existsSync(filePath)) {
      return res.json({ cutoffDate: '2026-07-31T23:59:59.999Z', items: [] });
    }

    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split(/\r?\n/).filter(line => line.trim().length > 0);
    const items = [];

    // Header: Athlete ID,Name,km
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      const parts = line.split(',');
      if (parts.length >= 3) {
        const rawId = (parts[0] || '').trim().replace(/^\uFEFF/, '');
        const name = (parts[1] || '').trim();
        const rawDist = (parts[2] || '').trim();
        const dist = rawDist ? parseFloat(rawDist) : null;

        const athleteId = rawId ? parseInt(rawId, 10) : null;

        if (name || athleteId) {
          items.push({
            name,
            athleteId,
            baseDistance: dist !== null && !isNaN(dist) ? dist : null
          });
        }
      }
    }

    res.json({
      cutoffDate: '2026-07-31T23:59:59.999Z',
      items
    });
  } catch (error) {
    console.error('Lỗi đọc total-km base:', error.message);
    res.status(500).json({ error: 'Không thể đọc dữ liệu Total-km' });
  }
});

// Cập nhật file Total-km CSV nếu cần
app.post('/api/challenge/total-km', (req, res) => {
  try {
    const { items, csvContent } = req.body;
    const dir = path.dirname(TOTAL_KM_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    if (csvContent) {
      fs.writeFileSync(TOTAL_KM_FILE, csvContent, 'utf8');
    } else if (Array.isArray(items)) {
      let csv = 'name,Dthletes,Distance\n';
      items.forEach(it => {
        const d = it.baseDistance !== null && it.baseDistance !== undefined ? it.baseDistance.toFixed(2) : '';
        const url = it.athleteUrl || (it.athleteId ? `/athletes/${it.athleteId}` : '');
        csv += `${it.name || ''},${url},${d}\n`;
      });
      fs.writeFileSync(TOTAL_KM_FILE, csv, 'utf8');
    }

    res.json({ success: true, message: 'Đã lưu Total-km' });
  } catch (error) {
    console.error('Lỗi lưu total-km:', error.message);
    res.status(500).json({ error: 'Không thể lưu Total-km' });
  }
});

// ==========================================
// LOGOUT
// ==========================================
app.post('/api/auth/logout', getToken, async (req, res) => {
  try {
    await strava.deauthorize(req.accessToken);
    tokenStore.delete(req.athleteId);
    saveTokens();
    res.json({ message: 'Đã đăng xuất' });
  } catch (error) {
    tokenStore.delete(req.athleteId);
    saveTokens();
    res.json({ message: 'Đã đăng xuất' });
  }
});

// ==========================================
// SERVE STATIC FILES (FOR DEPLOYMENT)
// ==========================================
// Cấu hình để backend Node.js tự động phục vụ file giao diện React (khi deploy)
const distPath = path.join(__dirname, '../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Strava API Server đang chạy tại http://localhost:${PORT}`);
});
