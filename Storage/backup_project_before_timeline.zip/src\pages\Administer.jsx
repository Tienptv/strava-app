import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { 
  Settings, 
  Users, 
  Shield, 
  FileText, 
  Database, 
  ArrowLeft, 
  RefreshCw, 
  Trash2, 
  Search, 
  Save, 
  CheckCircle,
  HardDrive,
  Activity,
  UserCheck,
  UserX,
  Plus
} from 'lucide-react';
import { useLang } from '../i18n/LangContext';

export default function Administer({ apiFetch, athlete, isSuperAdmin, isAdmin }) {
  const navigate = useNavigate();
  const { lang, t } = useLang();

  // Active Tab: 'settings', 'roles', 'logs', 'data'
  const [activeTab, setActiveTab] = useState('settings');

  // ==========================================
  // STATE: 1. CHALLENGE SETTINGS
  // ==========================================
  const [config, setConfig] = useState(null);
  const [loadingConfig, setLoadingConfig] = useState(false);
  const [savingConfig, setSavingConfig] = useState(false);

  // ==========================================
  // STATE: 2. ROLES & PERMISSIONS
  // ==========================================
  const [subAdmins, setSubAdmins] = useState([]);
  const [clubs, setClubs] = useState([]);
  const [selectedClubId, setSelectedClubId] = useState('');
  const [members, setMembers] = useState([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [memberSearchQuery, setMemberSearchQuery] = useState('');

  // ==========================================
  // STATE: 3. AUDIT LOGS
  // ==========================================
  const [logs, setLogs] = useState([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [logSearchQuery, setLogSearchQuery] = useState('');

  // ==========================================
  // STATE: 4. DATA MANAGEMENT
  // ==========================================
  const [storageFiles, setStorageFiles] = useState([]);
  const [loadingStorage, setLoadingStorage] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);

  // Load Settings
  const loadConfig = () => {
    setLoadingConfig(true);
    apiFetch('/challenge/config')
      .then(data => {
        setConfig(data || {
          allowEditOthers: false,
          defaultTarget: 50,
          penaltyRate: 10000,
          title: 'Journey from HCMC to the North Pole'
        });
      })
      .catch(err => console.error('Lỗi tải config:', err))
      .finally(() => setLoadingConfig(false));
  };

  // Load Sub-Admins
  const loadAdmins = () => {
    apiFetch('/admins')
      .then(data => setSubAdmins(data || []))
      .catch(err => console.error('Lỗi tải admins:', err));
  };

  // Load Audit Logs
  const loadLogs = () => {
    setLoadingLogs(true);
    apiFetch('/admin/audit-logs')
      .then(data => setLogs(data || []))
      .catch(err => console.error('Lỗi tải audit logs:', err))
      .finally(() => setLoadingLogs(false));
  };

  // Load Storage Stats
  const loadStorageStats = () => {
    setLoadingStorage(true);
    apiFetch('/admin/storage-stats')
      .then(res => {
        if (res && res.files) setStorageFiles(res.files);
      })
      .catch(err => console.error('Lỗi tải storage stats:', err))
      .finally(() => setLoadingStorage(false));
  };

  // Initial loads
  useEffect(() => {
    loadConfig();
    loadAdmins();
    loadLogs();
    loadStorageStats();

    // Lấy danh sách clubs
    apiFetch('/clubs')
      .then(data => setClubs(data || []))
      .catch(err => console.error('Lỗi tải clubs:', err));

    const handleConfigChange = (e) => {
      if (e.detail && e.detail.allowEditOthers !== undefined) {
        setConfig(prev => ({ ...prev, allowEditOthers: e.detail.allowEditOthers }));
      }
    };
    window.addEventListener('configChanged', handleConfigChange);
    return () => window.removeEventListener('configChanged', handleConfigChange);
  }, [apiFetch]);

  // Load members when club is selected
  useEffect(() => {
    if (selectedClubId) {
      setLoadingMembers(true);
      apiFetch(`/clubs/${selectedClubId}/members?per_page=200`)
        .then(data => setMembers(data || []))
        .catch(err => console.error('Lỗi tải members:', err))
        .finally(() => setLoadingMembers(false));
    } else {
      setMembers([]);
    }
  }, [selectedClubId, apiFetch]);

  // ==========================================
  // HANDLERS: SETTINGS
  // ==========================================
  const handleSaveConfig = async (e) => {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const res = await apiFetch('/challenge/config', {
        method: 'POST',
        body: JSON.stringify(config)
      });
      if (res.success) {
        Swal.fire({
          icon: 'success',
          title: 'Thành công',
          text: 'Đã lưu cấu hình thử thách thành công!',
          timer: 2000,
          showConfirmButton: false
        });
      }
    } catch (err) {
      Swal.fire('Lỗi', 'Không thể lưu cấu hình: ' + err.message, 'error');
    } finally {
      setSavingConfig(false);
    }
  };

  // ==========================================
  // HANDLERS: ROLES
  // ==========================================
  const handleAddAdmin = async (member) => {
    const uniqueId = member.id ? member.id.toString() : `${member.firstname}_${member.lastname}`;
    const memberName = `${member.firstname} ${member.lastname}`;
    try {
      const res = await apiFetch('/admins', {
        method: 'POST',
        body: JSON.stringify({ adminId: uniqueId, name: memberName })
      });
      if (res.success) {
        Swal.fire('Thành công', `Đã cấp quyền Admin cho ${memberName}`, 'success');
        setSubAdmins(res.admins);
        loadLogs();
        loadStorageStats();
      }
    } catch (e) {
      Swal.fire('Lỗi', e.message || 'Không thể cấp quyền admin', 'error');
    }
  };

  const handleRemoveAdmin = async (adminId) => {
    const confirm = await Swal.fire({
      title: 'Thu hồi quyền Admin?',
      text: `Bạn có chắc chắn muốn xóa quyền của tài khoản ID: ${adminId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Thu hồi ngay',
      cancelButtonText: 'Hủy',
      confirmButtonColor: '#d32f2f'
    });
    
    if (confirm.isConfirmed) {
      try {
        const res = await apiFetch(`/admins/${adminId}`, {
          method: 'DELETE'
        });
        if (res.success) {
          Swal.fire('Đã thu hồi', 'Đã xóa quyền admin thành công.', 'success');
          setSubAdmins(res.admins);
          loadLogs();
          loadStorageStats();
        }
      } catch (e) {
        Swal.fire('Lỗi', e.message || 'Không thể xóa quyền admin', 'error');
      }
    }
  };

  // ==========================================
  // HANDLERS: AUDIT LOGS
  // ==========================================
  const handleClearLogs = async () => {
    const confirm = await Swal.fire({
      title: 'Xóa sạch nhật ký hoạt động?',
      text: 'Toàn bộ bản ghi lịch sử audit log cũ sẽ bị xóa.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Xóa toàn bộ',
      cancelButtonText: 'Hủy',
      confirmButtonColor: '#d32f2f'
    });

    if (confirm.isConfirmed) {
      try {
        const res = await apiFetch('/admin/audit-logs', { method: 'DELETE' });
        if (res.success) {
          Swal.fire('Đã xóa', 'Nhật ký hoạt động đã được làm sạch.', 'success');
          setLogs([]);
        }
      } catch (e) {
        Swal.fire('Lỗi', e.message || 'Không thể xóa nhật ký', 'error');
      }
    }
  };

  // ==========================================
  // HANDLERS: DATA MANAGEMENT
  // ==========================================
  const handleSyncStorage = async () => {
    setProcessingAction(true);
    try {
      const res = await apiFetch('/challenge/sync-storage', { method: 'POST' });
      if (res.success) {
        Swal.fire('Đồng bộ hoàn tất', `Đã quét và hợp nhất thành công ${res.count} hoạt động từ thư mục Storage!`, 'success');
        loadStorageStats();
        loadLogs();
      }
    } catch (e) {
      Swal.fire('Lỗi', 'Không thể đồng bộ: ' + e.message, 'error');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleCreateBackup = async () => {
    setProcessingAction(true);
    try {
      const res = await apiFetch('/admin/backup', { method: 'POST' });
      if (res.success) {
        Swal.fire('Tạo bản sao lưu thành công', `File backup đã được lưu: <b>${res.filename}</b>`, 'success');
        loadLogs();
        loadStorageStats();
      }
    } catch (e) {
      Swal.fire('Lỗi', 'Không thể tạo bản sao lưu: ' + e.message, 'error');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleSyncMembers = async () => {
    setProcessingAction(true);
    try {
      const res = await apiFetch('/admin/sync-members', { method: 'POST' });
      if (res.success) {
        Swal.fire('Thành công', `Đã đồng bộ Tên và Avatar cho ${res.updatedCount} thành viên trong Challenge!`, 'success');
        loadLogs();
        loadStorageStats();
        window.dispatchEvent(new Event('challengeUpdated'));
      }
    } catch (e) {
      Swal.fire('Lỗi', 'Không thể đồng bộ thành viên: ' + e.message, 'error');
    } finally {
      setProcessingAction(false);
    }
  };

  // Filters
  const filteredMembers = members.filter(m => {
    const fullName = `${m.firstname} ${m.lastname}`.toLowerCase();
    return fullName.includes(memberSearchQuery.toLowerCase());
  });

  const filteredLogs = logs.filter(l => {
    const q = logSearchQuery.toLowerCase();
    return (
      (l.action || '').toLowerCase().includes(q) ||
      (l.user || '').toLowerCase().includes(q) ||
      (l.details || '').toLowerCase().includes(q)
    );
  });

  const formatFileSize = (bytes) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '–';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleString('vi-VN');
  };

  return (
    <div className="dashboard" style={{ padding: '24px', maxWidth: '1280px', margin: '0 auto' }}>
      
      {/* Header Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button 
            className="btn btn--secondary" 
            onClick={() => navigate('/')}
            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 14px', borderRadius: '8px', fontWeight: 600 }}
          >
            <ArrowLeft size={16} /> Trở về Dashboard
          </button>
          <div>
            <h1 style={{ fontSize: '1.75rem', fontWeight: 800, color: 'var(--primary-navy)', margin: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Shield size={28} color="var(--accent)" /> Bảng Quản Trị Administrator
            </h1>
            <p style={{ margin: '4px 0 0', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
              Trung tâm điều hành và quản lý hệ thống thử thách Strava Tracker
            </p>
          </div>
        </div>

        {/* Admin Badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {isSuperAdmin ? (
            <span style={{ 
              background: 'linear-gradient(135deg, #002D54 0%, #00A3A6 100%)', 
              color: '#fff', padding: '6px 14px', borderRadius: '20px', 
              fontSize: '0.85rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px',
              boxShadow: '0 2px 8px rgba(0, 163, 166, 0.3)'
            }}>
              ⭐ Super Admin (Toàn quyền)
            </span>
          ) : (
            <span style={{ 
              background: 'rgba(0, 45, 84, 0.08)', 
              color: 'var(--primary-navy)', padding: '6px 14px', borderRadius: '20px', 
              fontSize: '0.85rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px'
            }}>
              🛡️ Sub-Admin
            </span>
          )}
        </div>
      </div>

      {/* 4 Main Module Buttons / Tabs */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', 
        gap: '12px', 
        marginBottom: '28px' 
      }}>
        {/* Tab 1 */}
        <button
          onClick={() => setActiveTab('settings')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '16px 20px',
            borderRadius: '12px',
            border: activeTab === 'settings' ? '2px solid var(--accent)' : '1px solid var(--border)',
            background: activeTab === 'settings' ? '#ffffff' : 'var(--bg-glass)',
            boxShadow: activeTab === 'settings' ? '0 6px 16px rgba(0, 163, 166, 0.15)' : 'none',
            color: activeTab === 'settings' ? 'var(--primary-navy)' : 'var(--text-secondary)',
            cursor: 'pointer',
            textAlign: 'left',
            transition: 'all 0.2s ease',
            fontWeight: activeTab === 'settings' ? 700 : 500
          }}
        >
          <div style={{ 
            width: '40px', height: '40px', borderRadius: '10px', 
            background: activeTab === 'settings' ? 'var(--accent)' : 'rgba(0, 45, 84, 0.06)', 
            color: activeTab === 'settings' ? '#fff' : 'var(--primary-navy)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <Settings size={22} />
          </div>
          <div>
            <div style={{ fontSize: '1rem', fontWeight: 700 }}>1. Cấu hình chung</div>
            <div style={{ fontSize: '0.75rem', opacity: 0.8 }}>Challenge Settings</div>
          </div>
        </button>

        {/* Tab 2 */}
        <button
          onClick={() => setActiveTab('roles')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '16px 20px',
            borderRadius: '12px',
            border: activeTab === 'roles' ? '2px solid var(--accent)' : '1px solid var(--border)',
            background: activeTab === 'roles' ? '#ffffff' : 'var(--bg-glass)',
            boxShadow: activeTab === 'roles' ? '0 6px 16px rgba(0, 163, 166, 0.15)' : 'none',
            color: activeTab === 'roles' ? 'var(--primary-navy)' : 'var(--text-secondary)',
            cursor: 'pointer',
            textAlign: 'left',
            transition: 'all 0.2s ease',
            fontWeight: activeTab === 'roles' ? 700 : 500
          }}
        >
          <div style={{ 
            width: '40px', height: '40px', borderRadius: '10px', 
            background: activeTab === 'roles' ? 'var(--accent)' : 'rgba(0, 45, 84, 0.06)', 
            color: activeTab === 'roles' ? '#fff' : 'var(--primary-navy)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <Users size={22} />
          </div>
          <div>
            <div style={{ fontSize: '1rem', fontWeight: 700 }}>2. Quản lý phân quyền</div>
            <div style={{ fontSize: '0.75rem', opacity: 0.8 }}>Roles & Permissions</div>
          </div>
        </button>

        {/* Tab 3 */}
        <button
          onClick={() => setActiveTab('logs')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '16px 20px',
            borderRadius: '12px',
            border: activeTab === 'logs' ? '2px solid var(--accent)' : '1px solid var(--border)',
            background: activeTab === 'logs' ? '#ffffff' : 'var(--bg-glass)',
            boxShadow: activeTab === 'logs' ? '0 6px 16px rgba(0, 163, 166, 0.15)' : 'none',
            color: activeTab === 'logs' ? 'var(--primary-navy)' : 'var(--text-secondary)',
            cursor: 'pointer',
            textAlign: 'left',
            transition: 'all 0.2s ease',
            fontWeight: activeTab === 'logs' ? 700 : 500
          }}
        >
          <div style={{ 
            width: '40px', height: '40px', borderRadius: '10px', 
            background: activeTab === 'logs' ? 'var(--accent)' : 'rgba(0, 45, 84, 0.06)', 
            color: activeTab === 'logs' ? '#fff' : 'var(--primary-navy)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <FileText size={22} />
          </div>
          <div>
            <div style={{ fontSize: '1rem', fontWeight: 700 }}>3. Nhật ký hoạt động</div>
            <div style={{ fontSize: '0.75rem', opacity: 0.8 }}>Audit Logs ({logs.length})</div>
          </div>
        </button>

        {/* Tab 4 */}
        <button
          onClick={() => setActiveTab('data')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '16px 20px',
            borderRadius: '12px',
            border: activeTab === 'data' ? '2px solid var(--accent)' : '1px solid var(--border)',
            background: activeTab === 'data' ? '#ffffff' : 'var(--bg-glass)',
            boxShadow: activeTab === 'data' ? '0 6px 16px rgba(0, 163, 166, 0.15)' : 'none',
            color: activeTab === 'data' ? 'var(--primary-navy)' : 'var(--text-secondary)',
            cursor: 'pointer',
            textAlign: 'left',
            transition: 'all 0.2s ease',
            fontWeight: activeTab === 'data' ? 700 : 500
          }}
        >
          <div style={{ 
            width: '40px', height: '40px', borderRadius: '10px', 
            background: activeTab === 'data' ? 'var(--accent)' : 'rgba(0, 45, 84, 0.06)', 
            color: activeTab === 'data' ? '#fff' : 'var(--primary-navy)',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}>
            <Database size={22} />
          </div>
          <div>
            <div style={{ fontSize: '1rem', fontWeight: 700 }}>4. Quản lý dữ liệu</div>
            <div style={{ fontSize: '0.75rem', opacity: 0.8 }}>Data Management</div>
          </div>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB CONTENT 1: CẤU HÌNH CHUNG (CHALLENGE SETTINGS)                        */}
      {/* ========================================================================= */}
      {activeTab === 'settings' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
          
          <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '12px', borderBottom: '1px solid #f1f5f9' }}>
              <Settings size={22} color="var(--accent)" />
              <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                Quy tắc & Mục tiêu Thử thách
              </h2>
            </div>

            {loadingConfig ? (
              <p>Đang tải cấu hình...</p>
            ) : config ? (
              <form onSubmit={handleSaveConfig} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                <div>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '6px', color: 'var(--primary-navy)' }}>
                    Tiêu đề Thử thách (Challenge Title)
                  </label>
                  <input 
                    type="text"
                    value={config.title || 'Journey from HCMC to the North Pole'}
                    onChange={(e) => setConfig({ ...config, title: e.target.value })}
                    style={{ width: '100%', padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
                    placeholder="Nhập tiêu đề thử thách..."
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '6px', color: 'var(--primary-navy)' }}>
                      Target Mặc định (km/tháng)
                    </label>
                    <input 
                      type="number"
                      value={config.defaultTarget || 50}
                      onChange={(e) => setConfig({ ...config, defaultTarget: Number(e.target.value) })}
                      style={{ width: '100%', padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '6px', color: 'var(--primary-navy)' }}>
                      Mức Phạt thiếu km (VNĐ)
                    </label>
                    <input 
                      type="number"
                      value={config.penaltyRate || 10000}
                      onChange={(e) => setConfig({ ...config, penaltyRate: Number(e.target.value) })}
                      style={{ width: '100%', padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
                    />
                  </div>
                </div>

                <div style={{ 
                  background: 'rgba(0, 163, 166, 0.05)', 
                  padding: '14px', 
                  borderRadius: '10px', 
                  border: '1px dashed var(--accent)',
                  marginTop: '4px'
                }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 600, color: 'var(--primary-navy)', fontSize: '0.9rem' }}>
                    <input 
                      type="checkbox" 
                      id="allowEditAdmin" 
                      checked={!!config.allowEditOthers}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setConfig({ ...config, allowEditOthers: checked });
                        window.dispatchEvent(new CustomEvent('configChanged', { detail: { allowEditOthers: checked } }));
                      }}
                      style={{ width: '18px', height: '18px', accentColor: 'var(--accent)' }}
                    />
                    Cho phép các vận động viên tự cập nhật Target / Phạt cá nhân
                  </label>
                  <p style={{ margin: '6px 0 0 28px', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                    Nếu bật, mọi thành viên đều có thể tự sửa target và tick phạt của mình trên bảng thử thách.
                  </p>
                </div>

                <button 
                  type="submit" 
                  className="btn btn--primary" 
                  disabled={savingConfig}
                  style={{ 
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                    padding: '12px', borderRadius: '8px', fontWeight: 700, marginTop: '8px'
                  }}
                >
                  <Save size={18} /> {savingConfig ? 'Đang lưu...' : 'Lưu Cấu Hình Thử Thách'}
                </button>
              </form>
            ) : (
              <p>Không có cấu hình</p>
            )}
          </div>

          {/* Quick Help & Status */}
          <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '12px', borderBottom: '1px solid #f1f5f9' }}>
              <Activity size={22} color="var(--accent)" />
              <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                Thông tin Vận hành
              </h2>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div style={{ padding: '12px 16px', background: 'var(--bg-glass)', borderRadius: '10px', borderLeft: '4px solid #00A3A6' }}>
                <div style={{ fontWeight: 700, color: 'var(--primary-navy)', fontSize: '0.9rem' }}>Bộ môn được tính điểm:</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                  🏃 Run (Chạy bộ), 🏃‍♂️ Trail Run (Chạy địa hình), 🏃‍♂️ Virtual Run (Chạy trong nhà/máy).
                </div>
              </div>

              <div style={{ padding: '12px 16px', background: 'var(--bg-glass)', borderRadius: '10px', borderLeft: '4px solid #B5D334' }}>
                <div style={{ fontWeight: 700, color: 'var(--primary-navy)', fontSize: '0.9rem' }}>Quy tắc đồng bộ thông minh:</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                  Tự động loại bỏ bản ghi trùng lặp và làm sạch timezone GMT+7 khi import file CSV hoặc cạo dữ liệu.
                </div>
              </div>

              <div style={{ padding: '12px 16px', background: 'var(--bg-glass)', borderRadius: '10px', borderLeft: '4px solid #002D54' }}>
                <div style={{ fontWeight: 700, color: 'var(--primary-navy)', fontSize: '0.9rem' }}>Múi giờ & Chu kỳ:</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                  Tính toán theo tháng từ 01 đến 31 hàng tháng theo giờ Việt Nam.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT 2: QUẢN LÝ PHÂN QUYỀN (ROLES & PERMISSIONS)                    */}
      {/* ========================================================================= */}
      {activeTab === 'roles' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
          
          {/* Cột 1: Danh sách Admin */}
          <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', paddingBottom: '12px', borderBottom: '1px solid #f1f5f9' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Shield size={22} color="var(--accent)" />
                <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                  Danh sách Quản trị viên
                </h2>
              </div>
              <span style={{ fontSize: '0.8rem', background: '#e0f2fe', color: '#0369a1', padding: '4px 10px', borderRadius: '12px', fontWeight: 700 }}>
                {1 + subAdmins.length} Admins
              </span>
            </div>

            {/* Super Admin Item */}
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '8px' }}>
                Super Admin (Gốc)
              </div>
              <div style={{ 
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', 
                padding: '14px', background: 'rgba(0, 45, 84, 0.04)', borderRadius: '10px',
                border: '1px solid rgba(0, 45, 84, 0.1)'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--primary-navy)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
                    👑
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, color: 'var(--primary-navy)' }}>
                      {athlete ? `${athlete.firstname} ${athlete.lastname}` : 'Super Admin'}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      Strava ID: <b>{import.meta.env.VITE_ADMIN_STRAVA_ID || '133066813'}</b>
                    </div>
                  </div>
                </div>
                <span style={{ fontSize: '0.75rem', background: '#ecfdf5', color: '#059669', padding: '4px 8px', borderRadius: '6px', fontWeight: 700 }}>
                  Vĩnh viễn
                </span>
              </div>
            </div>

            {/* Sub-Admins List */}
            <div>
              <div style={{ fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '8px' }}>
                Sub-Admins ({subAdmins.length})
              </div>

              {subAdmins.length === 0 ? (
                <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)', background: 'var(--bg-glass)', borderRadius: '10px' }}>
                  Chưa có Sub-Admin nào được bổ nhiệm.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '350px', overflowY: 'auto' }}>
                  {subAdmins.map((adminId) => (
                    <div 
                      key={adminId} 
                      style={{ 
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center', 
                        padding: '12px 14px', border: '1px solid #e2e8f0', borderRadius: '10px',
                        background: '#ffffff'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{ width: '34px', height: '34px', borderRadius: '50%', background: 'rgba(0, 163, 166, 0.1)', color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
                          <UserCheck size={18} />
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, color: 'var(--primary-navy)', fontSize: '0.9rem' }}>
                            {adminId}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            Được phân quyền Sub-Admin
                          </div>
                        </div>
                      </div>

                      {isSuperAdmin && (
                        <button 
                          onClick={() => handleRemoveAdmin(adminId)}
                          className="btn btn--secondary"
                          style={{ 
                            color: '#dc2626', borderColor: '#fecaca', background: '#fef2f2',
                            padding: '6px 12px', fontSize: '0.8rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px'
                          }}
                        >
                          <UserX size={14} /> Thu hồi
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Cột 2: Cấp quyền Admin mới */}
          <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '12px', borderBottom: '1px solid #f1f5f9' }}>
              <Plus size={22} color="var(--accent)" />
              <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                Cấp quyền Admin Mới
              </h2>
            </div>

            {!isSuperAdmin ? (
              <div style={{ padding: '20px', background: '#fffbeb', borderRadius: '10px', border: '1px solid #fef3c7', color: '#b45309', fontSize: '0.9rem' }}>
                ⚠️ Chỉ có Super Admin mới có quyền chỉ định hoặc thu hồi quyền Sub-Admin.
              </div>
            ) : (
              <div>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', marginBottom: '6px', fontWeight: 600, fontSize: '0.85rem', color: 'var(--primary-navy)' }}>
                    1. Chọn Câu Lạc Bộ (Club)
                  </label>
                  <select 
                    className="sidebar__select"
                    style={{ width: '100%', padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
                    value={selectedClubId}
                    onChange={(e) => setSelectedClubId(e.target.value)}
                  >
                    <option value="">-- Chọn nhóm để tải thành viên --</option>
                    {clubs.map(club => (
                      <option key={club.id} value={club.id}>{club.name}</option>
                    ))}
                  </select>
                </div>

                {selectedClubId && (
                  <div>
                    <label style={{ display: 'block', marginBottom: '6px', fontWeight: 600, fontSize: '0.85rem', color: 'var(--primary-navy)' }}>
                      2. Tìm kiếm và Cấp quyền Thành viên
                    </label>
                    <div style={{ position: 'relative', marginBottom: '12px' }}>
                      <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', color: '#94a3b8' }} />
                      <input
                        type="text"
                        style={{ width: '100%', padding: '10px 14px 10px 36px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
                        placeholder="Tìm theo tên thành viên..."
                        value={memberSearchQuery}
                        onChange={(e) => setMemberSearchQuery(e.target.value)}
                      />
                    </div>
                    
                    <div style={{ maxHeight: '320px', overflowY: 'auto', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '8px' }}>
                      {loadingMembers ? (
                        <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)' }}>Đang tải danh sách thành viên...</div>
                      ) : filteredMembers.length > 0 ? (
                        filteredMembers.map((member) => {
                          const uniqueId = member.id ? member.id.toString() : `${member.firstname}_${member.lastname}`;
                          const isAlreadyAdmin = subAdmins.includes(uniqueId) || uniqueId === (import.meta.env.VITE_ADMIN_STRAVA_ID || '133066813');
                          
                          return (
                            <div 
                              key={uniqueId} 
                              style={{ 
                                display: 'flex', justifyContent: 'space-between', alignItems: 'center', 
                                padding: '10px 12px', borderBottom: '1px solid #f1f5f9',
                                transition: 'background 0.15s ease'
                              }}
                            >
                              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                {member.profile_medium ? (
                                  <img src={member.profile_medium} alt="avatar" style={{ width: 34, height: 34, borderRadius: '50%' }} />
                                ) : (
                                  <div style={{ width: 34, height: 34, borderRadius: '50%', background: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, fontSize: '0.8rem' }}>
                                    {(member.firstname || '?')[0]}
                                  </div>
                                )}
                                <div>
                                  <div style={{ fontWeight: 600, fontSize: '0.85rem', color: 'var(--primary-navy)' }}>
                                    {member.firstname} {member.lastname}
                                  </div>
                                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                    ID: {member.id || 'N/A'}
                                  </div>
                                </div>
                              </div>
                              
                              {isAlreadyAdmin ? (
                                <span style={{ color: '#059669', background: '#ecfdf5', padding: '4px 8px', borderRadius: '6px', fontWeight: 700, fontSize: '0.75rem' }}>
                                  ✓ Đã là Admin
                                </span>
                              ) : (
                                <button 
                                  className="btn btn--primary" 
                                  style={{ padding: '6px 12px', fontSize: '0.8rem', borderRadius: '6px', fontWeight: 600 }}
                                  onClick={() => handleAddAdmin(member)}
                                >
                                  Cấp quyền
                                </button>
                              )}
                            </div>
                          );
                        })
                      ) : (
                        <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                          Không tìm thấy thành viên nào.
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT 3: NHẬT KÝ HOẠT ĐỘNG (AUDIT LOGS)                              */}
      {/* ========================================================================= */}
      {activeTab === 'logs' && (
        <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <FileText size={22} color="var(--accent)" />
              <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                Nhật Ký Hoạt Động Hệ Thống (Audit Logs)
              </h2>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                onClick={loadLogs} 
                className="btn btn--secondary" 
                style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 14px', fontSize: '0.85rem', fontWeight: 600 }}
              >
                <RefreshCw size={14} /> Làm mới
              </button>
              {logs.length > 0 && (
                <button 
                  onClick={handleClearLogs} 
                  className="btn btn--secondary" 
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 14px', fontSize: '0.85rem', fontWeight: 600, color: '#dc2626', borderColor: '#fecaca', background: '#fef2f2' }}
                >
                  <Trash2 size={14} /> Xóa nhật ký
                </button>
              )}
            </div>
          </div>

          {/* Search bar */}
          <div style={{ position: 'relative', marginBottom: '16px' }}>
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '12px', color: '#94a3b8' }} />
            <input
              type="text"
              style={{ width: '100%', padding: '10px 14px 10px 36px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '0.9rem' }}
              placeholder="Tìm kiếm theo hành động, người thực hiện, hoặc chi tiết..."
              value={logSearchQuery}
              onChange={(e) => setLogSearchQuery(e.target.value)}
            />
          </div>

          {/* Table */}
          <div style={{ overflowX: 'auto', border: '1px solid #e2e8f0', borderRadius: '10px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
              <thead>
                <tr style={{ background: 'var(--bg-glass)', borderBottom: '1px solid #e2e8f0', color: 'var(--primary-navy)' }}>
                  <th style={{ padding: '12px 16px', fontWeight: 700, width: '180px' }}>Thời gian</th>
                  <th style={{ padding: '12px 16px', fontWeight: 700, width: '160px' }}>Hành động</th>
                  <th style={{ padding: '12px 16px', fontWeight: 700, width: '180px' }}>Người thực hiện</th>
                  <th style={{ padding: '12px 16px', fontWeight: 700 }}>Chi tiết</th>
                </tr>
              </thead>
              <tbody>
                {loadingLogs ? (
                  <tr>
                    <td colSpan="4" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
                      Đang tải nhật ký hoạt động...
                    </td>
                  </tr>
                ) : filteredLogs.length > 0 ? (
                  filteredLogs.map((log) => (
                    <tr key={log.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '12px 16px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                        {formatDate(log.timestamp)}
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ 
                          background: log.action.includes('Cấp quyền') ? '#ecfdf5' : 
                                      log.action.includes('Thu hồi') ? '#fef2f2' :
                                      log.action.includes('sao lưu') ? '#eff6ff' : 'rgba(0, 45, 84, 0.06)',
                          color: log.action.includes('Cấp quyền') ? '#059669' : 
                                 log.action.includes('Thu hồi') ? '#dc2626' :
                                 log.action.includes('sao lưu') ? '#2563eb' : 'var(--primary-navy)',
                          padding: '4px 10px', borderRadius: '6px', fontWeight: 600, fontSize: '0.8rem'
                        }}>
                          {log.action}
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', fontWeight: 600, color: 'var(--primary-navy)' }}>
                        {log.user}
                      </td>
                      <td style={{ padding: '12px 16px', color: 'var(--text-secondary)' }}>
                        {log.details}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
                      Chưa có nhật ký nào được ghi lại.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT 4: QUẢN LÝ DỮ LIỆU (DATA MANAGEMENT)                          */}
      {/* ========================================================================= */}
      {activeTab === 'data' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Action Toolbar */}
          <div className="card" style={{ padding: '20px 24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--primary-navy)', margin: '0 0 14px' }}>
              Tác vụ Nhanh với Dữ liệu Hệ thống
            </h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
              <button 
                onClick={handleSyncStorage}
                disabled={processingAction}
                className="btn btn--primary"
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', borderRadius: '8px', fontWeight: 600 }}
              >
                <RefreshCw size={16} /> Đồng bộ toàn bộ CSV trong Storage
              </button>

              <button 
                onClick={handleCreateBackup}
                disabled={processingAction}
                className="btn btn--secondary"
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', borderRadius: '8px', fontWeight: 600 }}
              >
                <HardDrive size={16} /> Tạo bản sao lưu tức thì (.zip)
              </button>

              <button 
                onClick={loadStorageStats}
                disabled={processingAction}
                className="btn btn--secondary"
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', borderRadius: '8px', fontWeight: 600 }}
              >
                <RefreshCw size={16} /> Làm mới trạng thái tệp
              </button>

              <button 
                onClick={handleSyncMembers}
                disabled={processingAction}
                className="btn btn--secondary"
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 18px', borderRadius: '8px', fontWeight: 600, color: '#059669', borderColor: '#a7f3d0', background: '#ecfdf5' }}
              >
                <Users size={16} /> Đồng bộ Thành viên
              </button>
            </div>
          </div>

          {/* Files List Table */}
          <div className="card" style={{ padding: '24px', background: '#fff', borderRadius: '16px', border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '12px', borderBottom: '1px solid #f1f5f9' }}>
              <Database size={22} color="var(--accent)" />
              <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--primary-navy)', margin: 0 }}>
                Trạng thái Các Tệp Dữ liệu (Storage Data Files)
              </h2>
            </div>

            <div style={{ overflowX: 'auto', border: '1px solid #e2e8f0', borderRadius: '10px' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
                <thead>
                  <tr style={{ background: 'var(--bg-glass)', borderBottom: '1px solid #e2e8f0', color: 'var(--primary-navy)' }}>
                    <th style={{ padding: '12px 16px', fontWeight: 700 }}>Tên Tệp / Mục đích</th>
                    <th style={{ padding: '12px 16px', fontWeight: 700, width: '120px' }}>Trạng thái</th>
                    <th style={{ padding: '12px 16px', fontWeight: 700, width: '130px' }}>Số bản ghi</th>
                    <th style={{ padding: '12px 16px', fontWeight: 700, width: '120px' }}>Dung lượng</th>
                    <th style={{ padding: '12px 16px', fontWeight: 700, width: '180px' }}>Cập nhật lần cuối</th>
                  </tr>
                </thead>
                <tbody>
                  {loadingStorage ? (
                    <tr>
                      <td colSpan="5" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
                        Đang kiểm tra dung lượng và trạng thái tệp...
                      </td>
                    </tr>
                  ) : storageFiles.length > 0 ? (
                    storageFiles.map((file) => (
                      <tr key={file.key} style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ fontWeight: 700, color: 'var(--primary-navy)' }}>{file.name}</div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{file.desc} ({file.key})</div>
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          {file.exists ? (
                            <span style={{ background: '#ecfdf5', color: '#059669', padding: '4px 8px', borderRadius: '6px', fontWeight: 700, fontSize: '0.75rem' }}>
                              ✓ Sẵn sàng
                            </span>
                          ) : (
                            <span style={{ background: '#fef2f2', color: '#dc2626', padding: '4px 8px', borderRadius: '6px', fontWeight: 700, fontSize: '0.75rem' }}>
                              Chưa tạo
                            </span>
                          )}
                        </td>
                        <td style={{ padding: '12px 16px', fontWeight: 600, color: 'var(--primary-navy)' }}>
                          {file.count !== undefined ? `${file.count.toLocaleString()} mục` : '–'}
                        </td>
                        <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>
                          {formatFileSize(file.size)}
                        </td>
                        <td style={{ padding: '12px 16px', color: 'var(--text-muted)' }}>
                          {formatDate(file.lastModified)}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="5" style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)' }}>
                        Không có tệp dữ liệu nào.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
